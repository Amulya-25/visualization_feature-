//https://developer.mozilla.org/en/docs/Web/JavaScript/Reference/Global_Objects/String/endsWith
if (!String.prototype.endsWith) {
  String.prototype.endsWith = function(searchString, position) {
      var subjectString = this.toString();
      if (typeof position !== 'number' || !isFinite(position) || Math.floor(position) !== position || position > subjectString.length) {
        position = subjectString.length;
      }
      position -= searchString.length;
      var lastIndex = subjectString.indexOf(searchString, position);
      return lastIndex !== -1 && lastIndex === position;
  };
}

var WallPostList = function(current_wall_uuid, current_user_name, current_wall_url, highlight, unhighlight) {
    this._current_wall_uuid = current_wall_uuid;
    this._posts = [];
    this._current_wall_url = current_wall_url;
    this._current_user_name = current_user_name;


    this._read = 0;
    this._wall_has_more_posts = true;
    this._total_posts = 0;

    this._seen_ids = {};
    this._load_highlight_only_posts = highlight;
    this._load_unhighlight_only_posts = unhighlight;
    this._load_text_only_posts = false;
    this._load_image_only_posts = false;
    this._load_highlight_first = false;
    this._network_map = "0";
    this._post_labels_filter = "";
    this._loadInProgress = false;
    this._append_at_the_end = true;


    this._limit = 30;
    this._offset = 0;
    this._loadInProgress = false;
}


WallPostList.prototype.resetData = function(current_wall_uuid, current_user_name, current_wall_url) {
    this._current_wall_uuid = current_wall_uuid;
    this._posts = [];
    this._current_wall_url = current_wall_url;
    this._current_user_name = current_user_name;
    this._limit = 30;
    this._offset = 0;
    this._append_at_the_end = true;

    this._read = 0;
    this._wall_has_more_posts = true;
    this._total_posts = 0;
    this._loadInProgress = false;
    this._seen_ids = {};
}
WallPostList.prototype.setOffset = function(offset) {
    this._offset = offset;
}
WallPostList.prototype.size = function() {
    return this._posts.length;
}
WallPostList.prototype.resetRead = function(posts) {
    this._read = 0;
    this._wall_has_more_posts = true;
    this._total_posts = 0;
    this._loadInProgress = false;
    this._append_at_the_end = true;
}
WallPostList.prototype.prepend = function(posts) {
    if (posts.length <= 0) {
        return;
    }
    var MAX_POSTS_LIMIT = 1000;
    var newarr = [];
    this._seen_ids = {}
    for(var i=0; i<posts.length; ++i) {
        if (this._seen_ids[posts[i].postid]) {
            continue;
        }
        if (this._load_image_only_posts && !posts[i].imagelink) {
            continue;
        }
        if (this._load_text_only_posts && !posts[i].text) {
            continue;
        }
        this._seen_ids[posts[i].postid] = true;
        newarr.push(posts[i]);
    }
    for (var i=0; i<this._posts.length; ++i) {
        if (this._seen_ids[this._posts[i].postid]) {
            continue;
        }
        newarr.push(this._posts[i]);
        this._seen_ids[this._posts[i].postid] = true;
        if (newarr.length >= MAX_POSTS_LIMIT) {
            break;
        }
    }
    this._posts = newarr;
}
WallPostList.prototype.wall_has_more_posts = function() {
    return this._wall_has_more_posts;
}
WallPostList.prototype.total_posts = function() {
    return this._total_posts;
}
WallPostList.prototype.getSearchOptions = function() {
    advancedoptions = new Object;
    advancedoptions.network_map = this._network_map;
    advancedoptions.post_labels_filter = this._post_labels_filter;
    if (this._load_highlight_first) {
        advancedoptions.highlightfirst = 'true';
    }
    if (this._load_highlight_only_posts) {
       advancedoptions.highlightonly = 'true';
       advancedoptions.unhighlightonly = 'false';
    } else if (this._load_unhighlight_only_posts) {
        advancedoptions.unhighlightonly = 'true';
        advancedoptions.highlightonly = 'false';
    } else {
        advancedoptions.unhighlightonly = 'false';
        advancedoptions.highlightonly = 'false';
    }
    if (this._load_text_only_posts != this._load_image_only_posts) {
        if (this._load_image_only_posts) {
            advancedoptions.imageonly = 'true';
        }
        if (this._load_text_only_posts) {
            advancedoptions.textonly = 'true';
        }
    }
    return advancedoptions;
}
WallPostList.prototype.wall_has_more_posts_to_append = function() {
    if (this._wall_has_more_posts) {
        return true;
    }
    if (this._read < this._posts.length) {
        return true;
    }
    return false;
}

WallPostList.prototype.getPostAtIndex = function(index) {
       if(index<this._posts.length){
           var postid =this._posts[index-1];
            return postid;
        }
        else{
            return null;
        } 
}
WallPostList.prototype.set_load_image_only_posts = function(load_image_only_posts) {
    this._load_image_only_posts = load_image_only_posts;
}
WallPostList.prototype.load_image_only_posts= function() {
    return this._load_image_only_posts;
}
WallPostList.prototype.set_load_highlight_first = function(load_highlight_first) {
    this._load_highlight_first = load_highlight_first;
}
WallPostList.prototype.load_highlight_first= function() {
    return this._load_highlight_first;
}
WallPostList.prototype.set_load_text_only_posts = function(load_text_only_posts) {
    this._load_text_only_posts = load_text_only_posts;
}
WallPostList.prototype.load_text_only_posts= function() {
    return this._load_text_only_posts;
}
WallPostList.prototype.set_network_map = function(networkmap) {
    this._network_map = networkmap;
}
WallPostList.prototype.set_post_labels_filter = function(label) {
    this._post_labels_filter = label;
}

WallPostList.prototype.set_load_highlight_only_posts = function(highlightonly) {
    this._load_highlight_only_posts = highlightonly;
}
WallPostList.prototype.load_highlight_only_posts = function() {
    return this._load_highlight_only_posts;
}
WallPostList.prototype.postApiSuccess = function(result, cb, cbarg) {
    var resultset = JSON.parse(result);
    var posts = resultset.results;
    var total = 0;
    if (resultset.total) {
        total = parseInt(resultset.total);
    }
    this._total_posts = total;



    if (resultset.hasMore == 'true') {
        this._wall_has_more_posts = true;
    } else {
        this._wall_has_more_posts = false;
    }

    if (!posts || posts.length == 0) {
        return cb(null, cbarg);
    }

    this._offset = this._offset + this._limit;

    for (var i=0; i<posts.length; ++i) {
        if (this._seen_ids[posts[i].postid]) {
            continue;
        }
        this._posts.push(posts[i]);
        this._seen_ids[posts[i].postid] = true;
    }
    this.getNextPost(cb, cbarg);
}
WallPostList.prototype.fetchPosts = function(cb, cbarg) {
    var url = "https://";

    url += this._current_wall_url;
    url += "/api/";
    url += this._current_user_name;
    url += "/";
    url += this._current_wall_uuid;
    url += "/posts/";

    var advancedoptions = this.getSearchOptions();
    var options = new Object;
    options.searchoptions = JSON.stringify(advancedoptions);

    options.limit = this._limit;
    options.offset = this._offset;

    var wallposts = this;

    $.getJSON(url, options).done(function(result) {
        wallposts.postApiSuccess(result, cb, cbarg);
    })
    .fail(function(result){
        console.log("url failure " + url);
        console.log(result);
        cb(null, cbarg);
    });
}
WallPostList.prototype.getPostFromId = function(postId) {
    for (var i=0; i<this._posts.length; ++i) {
        if (this._posts[i].postid == postId)
            return this._posts[i];
    }
    return null;
}
WallPostList.prototype.getPostAfterId = function(postId) {
    for (var i=0; i<this._posts.length; ++i) {
        if ( (this._posts[i].postid == postId) && ((i+1) < this._posts.length) )
            return this._posts[i+1];
    }
    return null;
}
WallPostList.prototype.getPostBeforeId = function(postId) {
    for (var i=0; i<this._posts.length; ++i) {
        if ( (this._posts[i].postid == postId) && ((i-1) >= 0) )
            return this._posts[i-1];
    }
    return null;
}
WallPostList.prototype.getLatestPost = function(size, slideCounter) {
    var limit = Math.min(size, this._posts.length);
    if (limit > 0) {
        limit = (limit + slideCounter) % limit;
        return this._posts[limit];
    }
    return null;
}
WallPostList.prototype.getLatestHighlightedPost = function(size, slideCounter) {
    var limit = this._posts.length;
    var highlightedPosts = [];
    for (var i=0; i<limit; ++i) {
        if (isPostHighlighted(this._posts[i])) {
            highlightedPosts.push(this._posts[i]);
        }
    }
    limit = highlightedPosts.length;
    if (limit > 0) {
        limit = (limit + slideCounter) % limit;
        return highlightedPosts[limit];
    }
    return null;
}
WallPostList.prototype.getRandomHighlightedPost = function(size, slideCounter) {
    var limit = this._posts.length;
    var highlightedPosts = [];
    for (var i=0; i<limit; ++i) {
        if (isPostHighlighted(this._posts[i])) {
            highlightedPosts.push(this._posts[i]);
        }
    }
    limit = highlightedPosts.length;
    if (limit > 0) {
        return highlightedPosts[Math.floor((Math.random() * 15485863)) % limit];
    }
    return null;
}
WallPostList.prototype.getRandomPost = function(size, slideCounter) {
    var limit = Math.min(size, this._posts.length);
    if (limit > 0) {
        return this._posts[Math.floor((Math.random() * 15485863)) % limit];
    }
    return null;
}
WallPostList.prototype.getLastPost = function(size, slideCounter) {

    var limit = Math.min(size, this._posts.length);

    if (limit > 0) {
        limit = limit - ((limit + slideCounter) % limit);
        return this._posts[limit-1];
    }
    return null;
}
WallPostList.prototype.getLastHighlightedPost = function(size, slideCounter) {
    var limit = this._posts.length;
    var highlightedPosts = [];
    for (var i=0; i<limit; ++i) {
        if (isPostHighlighted(this._posts[i])) {
            highlightedPosts.push(this._posts[i]);
        }
    }
    limit = highlightedPosts.length;
    if (limit > 0) {
        limit = limit - ((limit + slideCounter) % limit);
        return highlightedPosts[limit-1];
    }
    return null;
}
WallPostList.prototype.updatePost = function(post) {
    var found = false;
    for (var i=0; i<this._posts.length; ++i) {
        if (this._posts[i].postid == post.postid) {
            this._posts[i] = post;
            found = true;
        }
    }
    return found;
}
WallPostList.prototype.removePost = function(postid) {
    var newarr = [];
    var remCount = 0;
    var removed = false;
    for (var i=0; i<this._posts.length; ++i) {
        if (this._posts[i].postid != postid) {
            newarr.push(this._posts[i]);
        }
        else {
            if (i < this._read) {
                remCount = remCount + 1;
            }
            this._seen_ids[this._posts[i].postid] = false;
            removed = true;
        }
    }
    this._posts = newarr;
    this._read = Math.max(this._read - remCount, 0);
    return removed;
}
WallPostList.prototype.getNextPost = function(cb, cbarg) {
    if (this._read >= this._posts.length && !this._wall_has_more_posts) {
        if (cb)
            return cb(null, cbarg);
        else
            return null;
    }
    if (this._read >= this._posts.length) {
        if (this._append_at_the_end) {
            return this.fetchPosts(cb, cbarg);
        }
        else {
            if (cb)
                return cb(null, cbarg);
            else
                return null;
        }
    }

    this._read = this._read + 1;

    if (cb)
        return cb(this._posts[this._read - 1], cbarg);
    else
        return this._posts[this._read - 1];
}

var WallPosts = function(current_wall_uuid, current_user_name, current_wall_url) {
    this.allPosts = new WallPostList(current_wall_uuid, current_user_name, current_wall_url, false, false);
    this._highlight_post_count_limit = 1;
    this._highlight_repeat_distance = 5 + 1;
    this._highlightrepeat = 'true';
    this._highlight_only_popup = 'false';
}

WallPosts.prototype.setOffset = function(offset) {
    this.allPosts.setOffset(offset);
}

WallPosts.prototype.resetData = function(current_wall_uuid, current_user_name, current_wall_url) {
    this.allPosts.resetData(current_wall_uuid, current_user_name, current_wall_url);
}
WallPosts.prototype.size = function() {
    return this.allPosts.size();
}
WallPosts.prototype.resetRead = function(posts) {
    this.allPosts.resetRead(posts);
}
WallPosts.prototype.prepend = function(posts) {
    this.allPosts.prepend(posts);
}

WallPosts.prototype.wall_has_more_posts = function() {
    return this.allPosts.wall_has_more_posts();
}
WallPosts.prototype.total_posts = function() {
    return this.allPosts.total_posts();
}
WallPosts.prototype.wall_has_more_posts_to_append = function() {
    return this.allPosts.wall_has_more_posts_to_append();
}
WallPosts.prototype.set_load_image_only_posts = function(load_image_only_posts) {
    return this.allPosts.set_load_image_only_posts(load_image_only_posts);
}
WallPosts.prototype.load_image_only_posts= function() {
    return this.allPosts.load_image_only_posts();
}
WallPosts.prototype.set_load_highlight_first = function(load_highlight_first) {
    return this.allPosts.set_load_highlight_first(load_highlight_first);
}
WallPosts.prototype.getPostAtIndex = function(index) {
    return this.allPosts.getPostAtIndex(index);
}

WallPosts.prototype.load_highlight_first = function() {
    return this.allPosts.load_highlight_first();
}
WallPosts.prototype.set_load_text_only_posts = function(load_text_only_posts) {
    return this.allPosts.set_load_text_only_posts(load_text_only_posts);
}
WallPosts.prototype.load_text_only_posts= function() {
    return this.allPosts.load_text_only_posts();
}
WallPosts.prototype.set_network_map = function(networkmap) {
    return this.allPosts.set_network_map(networkmap);
}
WallPosts.prototype.set_post_labels_filter = function(label) {
    return this.allPosts.set_post_labels_filter(label);
}
WallPosts.prototype.set_load_highlight_only_posts = function(highlightonly) {
    return this.allPosts.set_load_highlight_only_posts (highlightonly);
}
WallPosts.prototype.load_highlight_only_posts = function() {
    return this.allPosts.load_highlight_only_posts();
}
WallPosts.prototype.getPostFromId = function(postId) {
    return this.allPosts.getPostFromId(postId);
}
WallPosts.prototype.getPostAfterId = function(postId) {
    return this.allPosts.getPostAfterId(postId);
}
WallPosts.prototype.getPostBeforeId = function(postId) {
    return this.allPosts.getPostBeforeId(postId);
}
WallPosts.prototype.getLatestPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        return this.allPosts.getLatestHighlightedPost(size, slideCounter);
    } else {
        return this.allPosts.getLatestPost(size, slideCounter);
    }
}
WallPosts.prototype.getRandomPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        return this.allPosts.getRandomHighlightedPost(size, slideCounter);
    } else {
        return this.allPosts.getRandomPost(size, slideCounter);
    }
}
WallPosts.prototype.getLastPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        return this.allPosts.getLastHighlightedPost(size, slideCounter);
    } else {
        return this.allPosts.getLastPost(size, slideCounter);
    }
}
WallPosts.prototype.updatePost = function(post) {

    var updated = this.allPosts.updatePost(post);
    if (!updated && isPostHighlighted(post)) {
        this.allPosts.prepend([post]);
    }
}
WallPosts.prototype.removePost = function(postid) {
    return this.allPosts.removePost(postid);
}
WallPosts.prototype.getNextPost = function(cb, cbarg) {
    return this.allPosts.getNextPost(cb, cbarg);
}
WallPosts.prototype.initHighlightOptions = function(highlight_post_count_limit, highlight_repeat_distance, highlightrepeat, highlight_only_popup) {
    this._highlight_post_count_limit = highlight_post_count_limit;
    this._highlight_repeat_distance = highlight_repeat_distance + 1;
    this._highlightrepeat = highlightrepeat;
    this._highlight_only_popup = highlight_only_popup;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
var WallPostsInserHighlight = function(current_wall_uuid, current_user_name, current_wall_url) {
    this.allPosts = new WallPostList(current_wall_uuid, current_user_name, current_wall_url, false, true);
    this.highlightPosts = new WallPostList(current_wall_uuid, current_user_name, current_wall_url, true, false);
    this.postcount = 0;
    this._highlight_post_insert_stopped = false;
    this._current_highlight_index = 0;

    this._highlight_post_count_limit = 1;
    this._highlight_repeat_distance = 5 + 1;
    this._highlightrepeat = 'true';
    this._highlight_only_popup = 'false';
}

WallPostsInserHighlight.prototype.setOffset = function(offset) {
    this.allPosts.setOffset(offset);
    this.highlightPosts.resetRead(null);
    this.postcount = 0;
    this._current_highlight_index = 0;
    this._highlight_post_insert_stopped = false;
}

WallPostsInserHighlight.prototype.resetData = function(current_wall_uuid, current_user_name, current_wall_url) {
    this.allPosts.resetData(current_wall_uuid, current_user_name, current_wall_url);
    this.highlightPosts.resetData(current_wall_uuid, current_user_name, current_wall_url);
    this.postcount = 0;
    this._current_highlight_index = 0;
    this._highlight_post_insert_stopped = false;
}
WallPostsInserHighlight.prototype.size = function() {
    return this.allPosts.size();
}
WallPostsInserHighlight.prototype.resetRead = function(posts) {
    this.allPosts.resetRead(posts);
    this.highlightPosts.resetRead(null);
    this.postcount = 0;
    this._current_highlight_index = 0;
    this._highlight_post_insert_stopped = false;
}
WallPostsInserHighlight.prototype.prepend = function(posts) {
    this.allPosts.prepend(posts);
}

WallPostsInserHighlight.prototype.wall_has_more_posts = function() {
    return this.allPosts.wall_has_more_posts();
}
WallPostsInserHighlight.prototype.total_posts = function() {
    return this.allPosts.total_posts();
}
WallPostsInserHighlight.prototype.wall_has_more_posts_to_append = function() {
    return this.allPosts.wall_has_more_posts_to_append();
}
WallPostsInserHighlight.prototype.set_load_image_only_posts = function(load_image_only_posts) {
    return this.allPosts.set_load_image_only_posts(load_image_only_posts);
}
WallPostsInserHighlight.prototype.load_image_only_posts= function() {
    return this.allPosts.load_image_only_posts();
}
WallPostsInserHighlight.prototype.set_load_highlight_first = function(load_highlight_first) {
    return this.allPosts.set_load_highlight_first(false);
}
WallPostsInserHighlight.prototype.load_highlight_first = function() {
    return this.allPosts.load_highlight_first();
}
WallPostsInserHighlight.prototype.set_load_text_only_posts = function(load_text_only_posts) {
    return this.allPosts.set_load_text_only_posts(load_text_only_posts);
}
WallPostsInserHighlight.prototype.load_text_only_posts= function() {
    return this.allPosts.load_text_only_posts();
}
WallPostsInserHighlight.prototype.set_network_map = function(networkmap) {
    this.allPosts.set_network_map(networkmap);
    this.highlightPosts.set_network_map(networkmap);
}
WallPostsInserHighlight.prototype.set_post_labels_filter= function(label) {
    this.allPosts.set_post_labels_filter(label);
    this.highlightPosts.set_post_labels_filter(label);
}
WallPostsInserHighlight.prototype.set_load_highlight_only_posts = function(highlightonly) {
    return this.allPosts.set_load_highlight_only_posts (false);
}
WallPostsInserHighlight.prototype.load_highlight_only_posts = function() {
    return this.allPosts.load_highlight_only_posts();
}
WallPostsInserHighlight.prototype.getLastPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        slideCounter = slideCounter % this._highlight_post_count_limit;
        return this.highlightPosts.getLastPost(this.highlightPosts.size(), slideCounter);
    } else {
        if (slideCounter % this._highlight_repeat_distance == 0) {
            slideCounter = slideCounter % this._highlight_post_count_limit;
            return this.highlightPosts.getLastPost(size, slideCounter);
        } else {
            return this.allPosts.getLastPost(size, slideCounter);
        }

    }

}
WallPostsInserHighlight.prototype.getPostFromId = function(postId) {
    var post = this.allPosts.getPostFromId(postId);
    if (!post) {
        post = this.highlightPosts.getPostFromId(postId);
    }
    return post;
}
WallPostsInserHighlight.prototype.getPostAfterId = function(postId) {
    var post = this.allPosts.getPostAfterId(postId);
    if (!post) {
        post = this.highlightPosts.getPostAfterId(postId);
    }
    return post;
}
WallPostsInserHighlight.prototype.getPostBeforeId = function(postId) {
    var post = this.allPosts.getPostBeforeId(postId);
    if (!post) {
        post = this.highlightPosts.getPostBeforeId(postId);
    }
    return post;
}
WallPostsInserHighlight.prototype.getLatestPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        slideCounter = slideCounter % this._highlight_post_count_limit;
        return this.highlightPosts.getLatestPost(this.highlightPosts.size(), slideCounter);
    } else {
        if (slideCounter % this._highlight_repeat_distance == 0) {
            slideCounter = slideCounter % this._highlight_post_count_limit;
            return this.highlightPosts.getLatestPost(size, slideCounter);
        } else {
            return this.allPosts.getLatestPost(size, slideCounter);
        }

    }
}
WallPostsInserHighlight.prototype.getRandomPost = function(size, slideCounter) {
    if (this._highlight_only_popup == 'true') {
        slideCounter = slideCounter % this._highlight_post_count_limit;
        return this.highlightPosts.getRandomPost(this.highlightPosts.size(), slideCounter);
    } else {
        if (slideCounter % this._highlight_repeat_distance == 0) {
            slideCounter = slideCounter % this._highlight_post_count_limit;
            return this.highlightPosts.getRandomPost(size, slideCounter);
        } else {
            return this.allPosts.getRandomPost(size, slideCounter);
        }

    }

}
WallPostsInserHighlight.prototype.updatePost = function(post) {
    var flag = post.wallflag;
    var highlighted = isPostHighlighted(post);
    if (highlighted) {
        this.allPosts.removePost(post.postid);
        if (!this.highlightPosts.updatePost(post)) {
            this.highlightPosts.prepend([post]);
        }
    } else { // post was unhighlighted
        var removed = this.highlightPosts.removePost(post.postid);
        if (!this.allPosts.updatePost(post) && removed) {
            this.allPosts.prepend([post]);
        }
    }
}
WallPostsInserHighlight.prototype.removePost = function(postid) {
    this.allPosts.removePost(postid);
    this.highlightPosts.removePost(postid);
}
WallPostsInserHighlight.prototype.get_highlight_post_limit = function() {
    return this._highlight_post_count_limit;
}
WallPostsInserHighlight.prototype.set_highlight_post_limit = function(limit) {
    this._highlight_post_count_limit = limit;
}

WallPostsInserHighlight.prototype.get_current_highlight_index = function() {
    return this._current_highlight_index;
}
WallPostsInserHighlight.prototype.set_current_highlight_index = function(index) {
    this._current_highlight_index = index;
}
WallPostsInserHighlight.prototype.set_highlight_post_insert_stopped = function(stop) {
    this._highlight_post_insert_stopped = stop;
}
WallPostsInserHighlight.prototype.get_highlight_post_insert_stopped = function() {
    return this._highlight_post_insert_stopped;
}
WallPostsInserHighlight.prototype.set_current_highlight_index = function(index) {
    this._current_highlight_index = index;
}
WallPostsInserHighlight.prototype.gethighlightrepeat = function() {
    return this._highlightrepeat == 'true';
}
WallPostsInserHighlight.prototype.getNextHighlightPost = function(cb, cbarg) {
    var wallposts = this;
    highlightpost = this.highlightPosts.getNextPost(function(post, arg) {
        if (post) {
            var limit = Math.min(wallposts.get_highlight_post_limit(), wallposts.highlightPosts.size());
            wallposts.set_current_highlight_index(wallposts.get_current_highlight_index() + 1);
            if (wallposts.get_current_highlight_index() >= limit) {
                if (!wallposts.gethighlightrepeat()) {
                    wallposts.set_highlight_post_insert_stopped(true);
                }
                wallposts.highlightPosts.resetRead(null);
                wallposts.set_current_highlight_index(0);
            }
            return cb(post, arg);
        }
        else {
            return wallposts.getNextPost(cb, arg);
        }
    }, cbarg);

}
WallPostsInserHighlight.prototype.getNextPost = function(cb, cbarg) {
    var highlightpost = null;
    if (!this.get_highlight_post_insert_stopped()) {
        if (this.postcount % this._highlight_repeat_distance == 0) {
            this.postcount = this.postcount + 1;
            return this.getNextHighlightPost(cb, cbarg);

        }
    }
    this.postcount = this.postcount + 1;
    return this.allPosts.getNextPost(cb, cbarg);
}
WallPostsInserHighlight.prototype.initHighlightOptions = function(highlight_post_count_limit, highlight_repeat_distance, highlightrepeat, highlight_only_popup) {
    this._highlight_post_count_limit = highlight_post_count_limit;
    this._highlight_repeat_distance = highlight_repeat_distance + 1;
    this._highlightrepeat = highlightrepeat;
    this._highlight_only_popup = highlight_only_popup;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////


function OpenInTab(url) {
  var winTab = window.open(url, '_blank');
  winTab.focus()
}

$(document).delegate("div.wallpost-essence", "click", function(e) {
   if ($(e.target).is("a")) {
        OpenInTab($(e.target).attr("href"));
   } else {
        if (WallData.magnifyBehavior == 'disable') {

        }
        else if (WallData.magnifyBehavior == 'newtab') {
            var url = $(this).find("a.wallpost-essence-target").attr("href");
            OpenInTab(url);
        } else {
            var postId = $(this).find("a.wallpost-essence-target").attr("data-postid");
            WallData.fillPostSlideFromId('#wallpost-slide', postId);
        }
   }
});


var WallData = function () {
    var current_wall_uuid = 0;
    var current_displayoptions;
    var current_wall_url = '';
    var current_parent_location = '';
    var current_user_name = '';
    var current_cursor = { max_time: "2029-01-01 00:00:00-05", hasMore: true };
    var current_highlight_cursor = { max_time: "2029-01-01 00:00:00-05", hasMore: true };
    var loadInProgress = false;
    var prevScrollTop = 0;
    var current_grid_columns = 1;
    var max_posts_to_append = 1;
    var current_repliace_grid_id = -1;
    var current_replace_pos = -1;
    var pop_up_type = 'split';

    var show_highlight_posts_first = false;
    var show_highlight_posts_only = false;

    var current_display_internal = false;

    var grids = [];

    return {
        inIframe: function() {
            try {
                return window.self !== window.top;
            } catch (e) {
                return true;
            }
        },
        initParentLocation: function(parent_location) {
            current_parent_location = parent_location;
        },
        initWidget: function(width, height, scrolling, fullscreen, parent_location) {
            current_parent_location = parent_location;
            if (WallData.inIframe()) {
                window.parent.postMessage({ 'init_embed': 'yes', 'scrolling': scrolling, 'width': width, 'height': height, 'fullscreen': fullscreen}, parent_location);
            } else {
                if (fullscreen == 'true') {
                    var css = 'body { border: 0; position:fixed; top:0; left:0; right:0; bottom:0; width: 100%; height: 100%;}';
                    head = document.head || document.getElementsByTagName('head')[0],
                    style = document.createElement('style');
                    style.type = 'text/css';
                    if (style.styleSheet){
                      style.styleSheet.cssText = css;
                    } else {
                      style.appendChild(document.createTextNode(css));
                    }
                    head.appendChild(style);
                }
            }
        },
        initSlick: function(slick) {
            WallData.slick = true;
        },
        initFlickity: function(flkty) {
            WallData.flkty = flkty;
        },
        init: function(id, url, username, posts_to_append, highlightpostposition) {
            current_wall_uuid = id;
            current_wall_url = url;
            current_user_name = username;
            switch (highlightpostposition) {
                case 'default':
                WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                break;
                case 'highlightfirst':
                WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                WallData.wallposts.set_load_highlight_first(true);
                break;
                case 'inserthighlight':
                WallData.wallposts = new WallPostsInserHighlight(current_wall_uuid, current_user_name, current_wall_url);
                break;
                default:
                WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                break;
            }

            WallData.highlightpostposition = highlightpostposition;
            WallData.appendId = 0;
            WallData.prependId = 0;
            WallData.replaceId = 0;
            WallData.load_more_on_scroll = false;
            WallData.loadPageSize = 20;
            scrolling = 'yes';
            max_posts_to_append = 1;
            WallData.replaceInProgress = false;
            WallData.prependInProgress = false;
            WallData.postHeaderStyle = 'classic';
            WallData.hlpostHeaderStyle = 'classic';
            WallData.postHeaderPosition = 'top';
            WallData.hlpostHeaderPosition = 'top';
            pop_up_type = 'split';
        },
        initPopupType: function(popuptype) {
            pop_up_type = popuptype;
        },
        initNetworkMap: function(networkmap) {
            WallData.wallposts.set_network_map(networkmap);
        },
        initPostLabelsFilter: function(label) {
            WallData.wallposts.set_post_labels_filter(label);
        },
        initHighlightOnly: function(highlightonly) {
            WallData.wallposts.set_load_highlight_only_posts(highlightonly);
        },
        initHighlightLoad: function() {
            //WallData.wallposts.set_load_highlight_first(true);
        },
        initDisplayOptions: function(displayoptions) {
            current_displayoptions = displayoptions;
        },
        initInternal: function(internal) {
            current_display_internal = internal;
        },
        initPostHeader: function(headerstyle, headerposition, hlheaderstyle, hlheaderposition) {
            WallData.postHeaderStyle = headerstyle;
            WallData.postHeaderPosition = headerposition;
            WallData.hlpostHeaderStyle = hlheaderstyle;
            WallData.hlpostHeaderPosition = hlheaderposition;
        },
        initFlickLayout: function(selector, gutterwidth, gridid) {

        },
        initMagnifyBehavior: function(value) {
            WallData.magnifyBehavior = value;
        },
        initPostType: function(posttype) {
            WallData.posttype = posttype;
        },
        initDefaultPostImageURL: function(imageurl) {
            WallData.defaultpostimage = imageurl;
          
        },
        initWallLayout: function(selector, gutterwidth, gridid) {
            selector = selector || '.wallitem';

            if (gutterwidth == null || typeof gutterwidth == 'undefined') {
                gutterwidth = 15;
            }

            var container = document.querySelector(gridid);
            if ( container ) {
                container.iso = new Isotope( container, {
                        layoutMode: 'masonry',
                        itemSelector: selector,
                        transitionDuration: 0,
                        transformsEnabled: true,
                        masonry: {
                            gutter : gutterwidth
                        },
                        hiddenStyle: {
                          opacity: 0
                        },
                        visibleStyle: {
                          opacity: 1
                        }
                     });
            }
        },
        initVideoWallLayout: function(selector, gutterwidth, gridid) {
            selector = selector || '.wallitem';

            if (gutterwidth == null || typeof gutterwidth == 'undefined') {
                gutterwidth = 15;
            }

            var container = document.querySelector(gridid);
            if ( container ) {
                container.iso = new Isotope( container, {
                        itemSelector: selector,
                        layoutMode: 'masonry',
                        transitionDuration: 0,
                        transformsEnabled: true,
                        percentPosition: true,

                        masonry: {
                          gutter : gutterwidth,
                          columnWidth: '.grid-sizer'
                        },
                        hiddenStyle: {
                          opacity: 0
                        },
                        visibleStyle: {
                          opacity: 1
                        }
                     });
            }
        },
        initScroll: function() {
            $(window).scroll(this.onScroll);
        },
        ignoreParentScroll: function() {
            return WallData.ignore_parent_scroll;
        },
        initLoadMoreOnScroll: function(enabled) {
            WallData.load_more_on_scroll = enabled;
            if ((!WallData.inIframe() || !WallData.auto_resize_enabled) && enabled) {
                WallData.ignore_parent_scroll = true;
                WallData.initScroll();
            }
        },
        initImageOnly: function(imageonly) {
            WallData.wallposts.set_load_image_only_posts(imageonly);
        },
        initTextOnly: function(textonly) {
            WallData.wallposts.set_load_text_only_posts(textonly);
        },
        initPageSize: function(pagesize) {
            WallData.loadPageSize = pagesize;
        },
        isLoadOnScrollEnabled: function() {
            return WallData.load_more_on_scroll;
        },
        initPostTextSize: function(posttextsize, hlposttextsize) {
            if (posttextsize && posttextsize != 'none') {
                WallData.post_textsize = posttextsize;
            }
            if (hlposttextsize && hlposttextsize != 'none') {
                WallData.hlpost_textsize = hlposttextsize;
            }
        },
        initHighlightOptions: function(highlight_post_count_limit, highlight_repeat_distance, highlightrepeat, highlight_only_popup) {
            WallData.highlight_post_count_limit = highlight_post_count_limit;
            WallData.highlight_repeat_distance = highlight_repeat_distance;
            WallData.highlightrepeat = highlightrepeat;
            WallData.highlight_only_popup = highlight_only_popup;
            WallData.wallposts.initHighlightOptions(highlight_post_count_limit, highlight_repeat_distance, highlightrepeat, highlight_only_popup);
        },
        getMediaSize: function() {
            return (WallData.post_imageheight ? WallData.post_imageheight : 'autoheight');
        },
        getHlMediaSize: function() {
            return (WallData.post_hlimageheight ? WallData.post_hlimageheight : 'autoheight');
        },
        initMediaSize: function(imageheight, hlimageheight) {
            if (imageheight && imageheight != 'none') {
                WallData.post_imageheight = imageheight;
            }
            if (hlimageheight && hlimageheight != 'none') {
                WallData.post_hlimageheight = hlimageheight;
            }
        },
        initPostAnimation: function(animationtype, hlanimationtype) {
            if (animationtype && animationtype != 'none') {
                WallData.post_animationtype = animationtype;
            }
            if (hlanimationtype && hlanimationtype != 'none') {
                WallData.post_hlanimationtype = hlanimationtype;
            }
        },
        initHostURLCheck: function(cb) {
            WallData.host_url_check_cb = cb;
            window.parent.postMessage({ host_url: 'true' }, current_parent_location);
        },
        hostUrlCheck: function(host_url) {
            WallData.host_url_check_cb(host_url);
        },
        getPostHeaderStyle: function() {
            if (!WallData.postHeaderStyle) {
                return 'classic';
            }
            return WallData.postHeaderStyle;
        },
        getPostHeaderPosition: function() {
            if (!WallData.postHeaderPosition) {
                return 'top';
            }
            return WallData.postHeaderPosition;
        },
        getHlPostHeaderStyle: function() {
            if (!WallData.hlpostHeaderStyle) {
                return 'classic';
            }
            return WallData.hlpostHeaderStyle;
        },
        getHlPostHeaderPosition: function() {
            if (!WallData.hlpostHeaderPosition) {
                return 'top';
            }
            return WallData.hlpostHeaderPosition;
        },
        getPostTextSize: function() {
            if (!WallData.post_textsize) {
                return 0;
            }
            return WallData.post_textsize;
        },
        getHlPostTextSize: function() {
            if (!WallData.hlpost_textsize) {
                return 0;
            }
            return WallData.hlpost_textsize;
        },
        getPostAnimation: function() {
            if (!WallData.post_animationtype) {
                return null;
            }
            if (WallData.post_animationtype != 'random') {
                return WallData.post_animationtype;
            } else {
                var animations = ["moveUp", "scaleUp", "fallPerspective", "flip", "helix", "popUp"]
                return animations[Math.floor((Math.random() * 15485863)) % animations.length];
            }
        },
        getHlPostAnimation: function() {
            if (!WallData.post_hlanimationtype) {
                return null;
            }
            if (WallData.post_hlanimationtype != 'random') {
                return WallData.post_hlanimationtype;
            } else {
                var animations = ["moveUp", "scaleUp", "fallPerspective", "flip", "helix", "popUp"]
                return animations[Math.floor((Math.random() * 15485863)) % animations.length];
            }
        },
        initAutoResizeOption: function(enabled) {
            if (WallData.inIframe()) {
                WallData.auto_resize_enabled = enabled;
            } else {
                WallData.auto_resize_enabled = false;
            }
        },
        onScroll: function() {

            if (!WallData.isLoadOnScrollEnabled()) {
                return;
            }

            height = $('body').height();
            var scrollLimit = height - 400;
            scrollTop = $(window).scrollTop();
            UP = -1;
            DOWN = 1;

            scrollDirection = (scrollTop > prevScrollTop) ? DOWN : UP;
            prevScrollTop = scrollTop;
            if (scrollDirection == DOWN && WallData.appendAllowed() &&  scrollLimit <= ($(window).height() + scrollTop)) {
                WallData.appendMorePosts();
            }
        },
        wallHasMorePosts: function() {
            return WallData.wallposts.wall_has_more_posts_to_append();
        },
        resetUIData: function(idtoclear) {
            wallitemclass = 'wallitem';
            var container = document.querySelector('#'+idtoclear);
            if (container) {
                if (typeof container.iso != "undefined" ){
                    if($('.'+wallitemclass).length > 0) {
                        container.iso.remove($('.'+wallitemclass));
                        container.iso.layout();
                    }
                }

                $('#'+idtoclear).empty();
                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }
            }
            WallData.loadInProgress = false;
            WallData.appendId++;
        },
        resetWallData: function() {
            WallData.loadInProgress = false;
            if (WallData.wallposts) {
                WallData.wallposts.resetData(current_wall_uuid, current_user_name, current_wall_url);
            } else {
                switch (WallData.highlightpostposition) {
                    case 'default':
                    WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                    break;
                    case 'highlightfirst':
                    WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                    WallData.wallposts.set_load_highlight_first(true);
                    break;
                    case 'inserthighlight':
                    WallData.wallposts = new WallPostsInserHighlight(current_wall_uuid, current_user_name, current_wall_url);
                    break;
                    default:
                    WallData.wallposts = new WallPosts(current_wall_uuid, current_user_name, current_wall_url);
                    break;
                }
            }
            WallData.appendId++;
            current_cursor.max_time = "2029-01-01 00:00:00-05";
            current_highlight_cursor.max_time = "2029-01-01 00:00:00-05";
        },
        reloadFrame: function() {
            if (WallData.inIframe()) {
                window.parent.postMessage({ 'reload_frame': 'yes'}, current_parent_location);
            } else {
                location.reload();
            }
        },
        highlightPostInGrid: function(postid, post) {
            found = false;
            WallData.wallposts.updatePost(post);
            isotopepostid = 'wallitem-' + postid;

            for (var i=0; i<total_grid_columns; i++) {
                var container = document.querySelector('#postgrid-'+i);
                if (typeof container.iso != "undefined" ){
                    if($('.'+isotopepostid).length > 0) {
                        found = true;
                        $('.'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('.'+isotopepostid).addClass('wallitem-highlight');
                        $('.'+isotopepostid).addClass(WallData.getHlMediaSize());
                    }
                } else {
                    if($('#postgrid-'+i+' .'+isotopepostid).length > 0) {
                        $('#postgrid-'+i+' .'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('#postgrid-'+i+' .'+isotopepostid).addClass('wallitem-highlight');
                        $('#postgrid-'+i+' .'+isotopepostid).addClass(WallData.getHlMediaSize());
                        found = true;
                    }
                    if($('#slidecopy-postgrid-'+i+' .'+isotopepostid).length > 0) {
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).addClass('wallitem-highlight');
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).addClass(WallData.getHlMediaSize());
                        found = true;
                    }
                    container.iso.layout();
                }
            }

            if (found) {
                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }
            }
        },
        unhighlightPostInGrid: function(postid, post) {
            found = false;
            WallData.wallposts.updatePost(post);
            isotopepostid = 'wallitem-' + postid;

            for (var i=0; i<total_grid_columns; i++) {
                var container = document.querySelector('#postgrid-'+i);
                if (typeof container.iso != "undefined" ){
                    if($('.'+isotopepostid).length > 0) {
                        found = true;
                        $('.'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('.'+isotopepostid).removeClass('wallitem-highlight');
                        $('.'+isotopepostid).addClass(WallData.getMediaSize());
                    }
                } else {
                    if($('#postgrid-'+i+' .'+isotopepostid).length > 0) {
                        $('#postgrid-'+i+' .'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('#postgrid-'+i+' .'+isotopepostid).removeClass('wallitem-highlight');
                        $('#postgrid-'+i+' .'+isotopepostid).addClass(WallData.getMediaSize());
                        found = true;
                    }
                    if($('#slidecopy-postgrid-'+i+' .'+isotopepostid).length > 0) {
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).removeClass('custom').removeClass('square').removeClass('autoheight');
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).removeClass('wallitem-highlight');
                        $('#slidecopy-postgrid-'+i+' .'+isotopepostid).addClass(WallData.getMediaSize());
                        found = true;
                    }
                    container.iso.layout();
                }
            }
            if (found) {
                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }
            }
        },
        
        removePostFromUI: function(postid) {
            var found = false;
            isotopepostid = 'wallitem-' + postid;

            for (var i=0; i<total_grid_columns; i++) {
                var container = document.querySelector('#postgrid-'+i);
                if (typeof container.iso != "undefined" ){
                    if($('.'+isotopepostid).length > 0) {
                        found = true;
                        container.iso.remove($('.'+isotopepostid));
                        container.iso.layout();
                    }
                } else {
                    if($('#postgrid-'+i+' .'+isotopepostid).length > 0) {
                        $('#postgrid-'+i+' .'+isotopepostid).remove();
                        found = true;
                    }
                }

                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }
            }
            return found;
        },
        
        removePostFromGrid: function(postid, cb) {
            
            WallData.wallposts.removePost(postid);
            var found = WallData.removePostFromUI(postid);
            

            if (cb) {
                cb(found);
            }
        },

        appendAllowed: function(){
            return (!WallData.loadInProgress && WallData.wallHasMorePosts());
        },

        getValidVideoPosts: function(posts, cb, cbarg){
            var videoposts = [];
            var validposts = [];
            var origpostorder = [];
            var videoExists = false;

            for(var index = 0; index < posts.length; ++index) {
                validposts.push(null);
                var postobj = posts[index];

                if (postobj.source == "instagram" && postobj.videolink) {
                    videoposts.push(postobj.videolink);
                    origpostorder.push(index);
                    videoExists = true;
                } else {
                    validposts[index] = posts[index];
                }
            }

            var promises = [];
            var total = 0;

            for (var index = 0; index < videoposts.length; index++) {
                (function(url, promise, pos) {
                    var http = new XMLHttpRequest();
                    http.open('HEAD', url);
                    http.onreadystatechange = function() {
                        if (this.readyState == this.DONE) {
                            if(this.status == 200) {
                                total++;
                                validposts[ pos ] = posts[ pos ];
                            } else {
                                total++;
                            }
                            promise.resolve();
                        }
                    };
                    http.send();
                })(videoposts[index], promises[index] = $.Deferred(), origpostorder[index]);
            }


            $.when.apply($, promises).done(function() {
                if (total >= videoposts.length) {
                    trimvalidposts = [];
                    for (var i=0; i<validposts.length; i++) {
                        if (validposts[i]) {
                            trimvalidposts.push(validposts[i]);
                        }
                    }
                    WallData.getValidVideoPostsAfter(trimvalidposts, cb, cbarg);
                    return;
                }
            });
        },

        getValidPosts: function(posts, cb, cbarg){
            WallData.getValidVideoPosts(posts, cb, cbarg);
        },

        getValidVideoPostsAfter: function(posts, cb, cbarg) {
            WallData.getValidImagePosts(posts, cb, cbarg);
        },

        getValidImagePosts: function(posts, cb, cbarg){
            var authorimages = [];
            var postimages = [];
            var validposts = [];
            var origpostorder = [];

            for(var index = 0; index < posts.length; ++index) {
                validposts.push(null);
                var postobj = posts[index];

                if (postobj.authorimage) {
                    authorimages.push(postobj.authorimage);
                }

                if (postobj.imagelink) {
                    postimages.push(postobj.imagelink);
                    origpostorder.push(index);
                    imagesExist = true;
                } else {
                    validposts[index] = posts[index];
                }
            }

            var promises = [];
            var total = 0;

            for (var index = 0; index < postimages.length; index++) {
                (function(url, promise, pos) {
                    var img = new Image();
                    img.onload = function() {
                        total++;
                        validposts[ pos ] = posts[ pos ];
                        promise.resolve();
                    };
                    img.onerror = function() {
                        total++;
                        promise.resolve();
                    };
                    img.src = url;
                })(postimages[index], promises[index] = $.Deferred(), origpostorder[index]);
            }



            for (var index = 0; index < authorimages.length; index++) {
                var img = new Image();
                img.src = authorimages[index];
            }

            $.when.apply($, promises).done(function() {
                if (total >= postimages.length) {
                    trimvalidposts = [];
                    for (var i=0; i<validposts.length; i++) {
                        if (validposts[i]) {
                            trimvalidposts.push(validposts[i]);
                        }
                    }
                    cb(trimvalidposts, cbarg);
                    return;
                }
            });

        },

        hidePostSlide: function() {
            $('.wallpost-slide').html('');
            //$('.wallpost-slide').removeClass('show').addClass('hide');
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('hide');
                $('#wallpost-modal').hide();
            }
            if (WallData.inIframe()) {
                window.parent.postMessage({ hide_view_post: 1 }, current_parent_location);
            }
        },

        showPostSlide: function() {
            //$('.wallpost-slide').removeClass('hide').addClass('show');
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('show');
            }
        },
        printpost:function(index){
            var post=WallData.wallposts.getPostAtIndex(index);  
            console.log(post.postid);
            if(post!=null && post.postid!=null){
                WallData.removePostFromUI(post.postid); 
                WallData.ShowPostsAtFront([post]);
            }
        },
        getPostAfterId: function(elemId, postId) {
            $(elemId).html('');
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('hide');
                $('#wallpost-modal').hide();
            }
            var post = WallData.wallposts.getPostAfterId(postId);
            window.parent.postMessage({ view_post: post }, current_parent_location);
        },

        getPostBeforeId: function(elemId, postId) {
            $(elemId).html('');
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('hide');
                $('#wallpost-modal').hide();
            }
            var post = WallData.wallposts.getPostBeforeId(postId);
            window.parent.postMessage({ view_post: post }, current_parent_location);
        },

        fillPostSlideFromId: function(elemId, postId) {
            $(elemId).html('');
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('hide');
                $('#wallpost-modal').hide();
            }
            var post = WallData.wallposts.getPostFromId(postId);
            window.parent.postMessage({ view_post: post }, current_parent_location);
        },

        fillPostSlide: function(elemId, strategy, slideCounter, contain_view) {
            var post;
            switch (strategy) {
                case 'latest':
                post = WallData.wallposts.getLatestPost(WallData.loadPageSize, slideCounter);
                break;
                case 'last':
                post = WallData.wallposts.getLastPost(WallData.loadPageSize, slideCounter);
                break;
                case 'random':
                post = WallData.wallposts.getRandomPost(WallData.loadPageSize, slideCounter);
                break;
            }

            if (!post) {
                return;
            }

            if (!contain_view) {
                var view_post_options = new Object;
                view_post_options.hide_contorls = true;
                view_post_options.ignore_ga = "true";

                window.parent.postMessage({ view_post: post,  view_post_options: view_post_options}, current_parent_location);
            } else {
                var posts = [];
                posts.push(post);
                WallData.getValidPosts(posts, WallData.fillPostSlideValid, {"elemId":elemId, "cb":WallData.showPostSlideValid});
            }
        },

        getNextSlidePost: function(postid) {
            if (!postid) {
                return;
            }
            if (WallData.inIframe()) {
                var elemId = '#wallpost-slide';
                $(elemId).html('');
                if ($('#wallpost-modal').length > 0) {
                    $('#wallpost-modal').modal('hide');
                    $('#wallpost-modal').hide();
                }
                $('.social-media-wall-prev-next-button.next').prop('disabled', true);
                window.parent.postMessage({ get_next_slide_post: postid }, current_parent_location);
            }
        },

        getPrevSlidePost: function(postid) {
            if (!postid) {
                return;
            }
            if (WallData.inIframe()) {
                var elemId = '#wallpost-slide';
                $(elemId).html('');
                if ($('#wallpost-modal').length > 0) {
                    $('#wallpost-modal').modal('hide');
                    $('#wallpost-modal').hide();
                }
                $('.social-media-wall-prev-next-button.previous').prop('disabled', true);
                window.parent.postMessage({ get_prev_slide_post: postid }, current_parent_location);
            }
        },

        centerSlideText: function() {
            var container = document.getElementsByClassName("post-text");
            if (container.length > 0) {
                //var container = container[0];
                //var inner = container.getElementsByClassName("wallpost-text");
                //if (inner.length > 0) {
                //    inner = inner[0];
                //    var inHeight = inner.offsetHeight;
                //    var conHeight = container.offsetHeight;
                //    inner.style.paddingTop = ((conHeight-inHeight)/2)+'px';
                //}
                //textFit(container, {minFontSize:12, maxFontSize: 40, detectMultiLine: true, multiLine: true, alignHoriz: false, alignVert: true, reProcess: true});
            }
        },

        showPostSlideValid: function(post, elemId) {
            if ($('#wallpost-modal').length > 0) {
                $('#wallpost-modal').modal('show');
            }
        },

        fillPostSlideValid: function(posts, args) {
            var elemId = args["elemId"];
            var cb = args["cb"];
            if (!posts || posts.length == 0) {
                WallData.fillPostSlide(elemId, 'random', 0);
                return;
            }
            $(elemId).empty();

            var postobj = posts[0];
            if (postobj.imagelink && postobj.videolink) {
                $("<img/>").load(function() {
                    var real_width = this.width;
                    var real_height = this.height;
                    var stylestr = '';
                    if (real_width > real_height) {
                        var ratio = (real_height * 100)/real_width;
                        var margin = (100-ratio) / 2;
                        stylestr = 'padding-bottom:'+ratio+'% !important;margin-top:'+margin+'%  !important;';
                    } else {
                        var ratio = (real_width * 100)/real_height;
                        var margin = (100-ratio) / 2;
                        stylestr = 'height:100%;width:'+ratio+'% !important;margin-left:'+margin+'%  !important;';
                    }
                    if (pop_up_type == 'mediaonly') {
                        post_html = getPostSlideMarkup2(postobj, true, stylestr);
                    } else {
                        post_html = getPostSlideMarkup(postobj, true, stylestr);
                    }
                    var contents = $('<div/>').html(post_html).contents();
                    $(elemId).html(contents);
                    if (twttr) {
                        twttr.widgets.load();
                    }
                    cb(postobj, elemId);
                }).attr("src", postobj.imagelink);
            } else {

                if (pop_up_type == 'mediaonly') {
                    post_html = getPostSlideMarkup2(postobj, true);
                } else {
                    post_html = getPostSlideMarkup(postobj, true);
                }
                var contents = $('<div/>').html(post_html).contents();
                $(elemId).html(contents);
                if (twttr) {
                    twttr.widgets.load();
                }
                cb(postobj, elemId);
            }

        },
        getTotalPosts: function() {
            return WallData.wallposts.total_posts();
        },
        setOffset: function(offset) {
            WallData.wallposts.setOffset(offset);
        },
        appendMorePosts: function() {
            if (!WallData.appendAllowed()) {
                return;
            }
            WallData.appendBegin();
            WallData.ShowPosts(WallData.appendId);
        },

        replaceMorePosts: function(posts) {
            WallData.ReplaceOlderPosts(posts);
        },
        loadedFullPage: function() {
            return (WallData.wallposts.size() >= WallData.loadPageSize);
        },
        ReplaceOlderPosts: function(posts) {
            WallData.replaceBegin();

            posts = '[' + posts + ']';
            var posts = JSON.parse(posts);
            if (!posts || posts.length == 0) {
                WallData.replaceOver();
                return;
            }

            WallData.getValidPosts(posts, WallData.replaceGridPosts, 0);
        },
        prependMorePostsInBuffer: function(posts) {
            var newposts = '[' + posts + ']';
            newposts = JSON.parse(newposts);
            if (!newposts || newposts.length == 0) {
                return;
            }
            WallData.wallposts.prepend(newposts);
        },
        resetRead: function() {
            WallData.wallposts.resetRead();
        },
        prependMorePosts: function(posts) {
            posts = '[' + posts + ']';
            var posts = JSON.parse(posts);
            if (!posts || posts.length == 0) {
                WallData.prependOver();
                return;
            }
            WallData.wallposts.prepend(posts);
            WallData.ShowPostsAtFront(posts);
            WallData.LimitPostsInView();
        },

        LimitPostsInView: function() {
            var LIMIT = 50;
            var gridid = WallData.getGridId();
            var container = document.querySelector(gridid);
            if (typeof container.iso != "undefined" ){
                container.iso.remove($(gridid).children('.wallitem').slice(LIMIT, -1));
            }
        },

        ShowPostsAtFront: function(posts) {
            WallData.prependBegin();
            WallData.getValidPosts(posts, WallData.prependGrid, 0);
        },

        ShowPosts: function(appendId) {
            WallData.wallposts.getNextPost(WallData.onPostAPISuccess, appendId)
        },

        GetNextPost: function(cb, appendId) {
            WallData.wallposts.getNextPost(cb, appendId);
        },

        onPostAPISuccess: function(post, appendId){
            if (!post) {
                WallData.appendOver();
                return;
            }

            posts = [];
            posts.push(post);
            WallData.getValidPosts(posts, WallData.appendGrid, appendId);
        },

        appendGrid: function(posts, appendId) {
            if (posts.length == 0) {
                WallData.ShowPosts(appendId);
                return;
            }

            var index = 0;
            WallData.append(posts, index, appendId);
        },

        replaceGridPosts: function(posts) {
            if (posts.length == 0) {
                WallData.replaceOver();
                return;
            }

            var index = 0;
            WallData.replaceId++;
            WallData.replace(posts, 0, WallData.replaceId);
        },

        prependGrid: function(posts) {
            if (posts.length == 0) {
                WallData.prependOver();
                return;
            }

            var index = 0;
            WallData.prependId++;
            WallData.prepend(posts, WallData.prependId);
        },

        append: function(posts, index, appendId) {
            if (WallData.appendId != appendId) {
                return;
            }
            if (!posts) {
                WallData.appendOver();
                return;
            }

            if (WallData.loadCount >= WallData.loadPageSize) {
                var len = posts.length;

                WallData.appendOver();
                return;
            }

            var len = posts.length;
            if (index >= len) {
                WallData.ShowPosts(appendId);
                return;
            }

            loadRemaining = WallData.loadPageSize - WallData.loadCount;

            gridid = WallData.getGridId();
            grididnum = WallData.getCurrentGridId();

            number_of_posts_to_append = Math.min(loadRemaining, max_posts_to_append);
            var post_html = '';
            for (var i=0; i<number_of_posts_to_append; ++i) {
                var postobj = posts[index];
                grids[grididnum].push(postobj.postid);
                if (WallData.posttype == 'grid') {
                    post_html += getPostMarkup(postobj);
                } else if (WallData.posttype == 'slide') {
                    post_html += getPostSlideMarkup(postobj, false, '');
                } else if (WallData.posttype == 'imagegrid') {
                    post_html += getPostImageMarkup(postobj, false);
                } else if (WallData.slick) {
                    post_html += getPostMarkup(postobj);
                }
                else {
                    post_html += getPostMarkup(postobj);
                }
                index = index + 1;
                WallData.loadCount++;
                if (index >= len) {
                    break;
                }
            }

            var container = document.querySelector(gridid);
            var contents = $('<div/>').html(post_html).contents();

            if (WallData.appendId != appendId) {
                return;
            }

            if (WallData.flkty) {
                WallData.flkty.append(contents);
                if (WallData.posttype == 'slide') {
                    WallData.centerSlideText();
                    if (twttr) {
                        twttr.widgets.load();
                    }
                }
            }else if (WallData.slick) {
                $(gridid).append(contents);
            }
            else {
                $(gridid).append(contents);
            }

            var container = document.querySelector(gridid);
            if ( container ) {

                if (typeof container.iso !== "undefined") {
                    container.iso.appended(contents);
                }



                imagesLoaded(container, function() {
                    if (typeof container.iso !== "undefined") {
                        container.iso.layout();
                    }
                    $('.transaparent-isotope').toggleClass('transaparent-isotope');
                    if (WallData.auto_resize_enabled) {
                        window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                    }
                    WallData.append(posts, index, appendId);
                 });
            }
            else {
            }
        },

        prepend: function(posts, prependId) {
            postsmarkup = '';
            for (var i = posts.length-1; i >= 0; --i)
            {
                postsmarkup += getPostMarkup(posts[i]);
            }
            var postselems = $('<div/>').html(postsmarkup).contents();

            if (prependId != WallData.prependId) {
                WallData.prependOver();
                return;
            }

            gridid = WallData.getGridId();
            $(gridid).prepend(postselems);

            var container = document.querySelector(gridid);
            if (typeof container.iso !== "undefined") {
                container.iso.prepended(postselems);
            }
            imagesLoaded(container, function() {
                if (typeof container.iso !== "undefined") {
                    container.iso.layout();
                }

                $('.transaparent-isotope').toggleClass('transaparent-isotope');

                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }

                WallData.prependOver();
            });
        },

        getReplaceElem: function() {
            if (current_repliace_grid_id < 0) {
                current_repliace_grid_id = total_grid_columns - 1;
            }

            if (current_replace_pos < 0) {
                current_replace_pos = grids[0].length - 1;
            }

            for(var i=current_repliace_grid_id; i>=0; i--) {
                if (grids[i].length > current_replace_pos) {
                    retobject = new Object;
                    retobject.pos = current_replace_pos;
                    retobject.gridid = i;
                    retobject.replaceelem = grids[i][current_replace_pos];
                    if (i==0) {
                        current_replace_pos--;
                    }
                    current_repliace_grid_id = i-1;

                    return retobject;
                }
            }

            return null;
        },

        replace: function(posts, index, replaceId) {

            if (index >= posts.length) {
                WallData.replaceOver();
                return;
            }

            if (replaceId != WallData.replaceId) {
                WallData.replaceOver();
                return;
            }

            postsmarkup = '';
            postsmarkup += getPostMarkup(posts[index]);
            var postelems = $('<div/>').html(postsmarkup).contents();

            retobject = WallData.getReplaceElem();

            replaceelem = '#postgrid-' + retobject.gridid + ' .wallitem-'+ retobject.replaceelem;
            newelems = '.wallitem-'+posts[index].postid

            grids[retobject.gridid][retobject.pos] = posts[index].postid;

            gridid = '#postgrid-'+retobject.gridid

            var container = document.querySelector(gridid);


            WallData.removePostFromGrid(retobject.replaceelem);
            $(gridid).prepend(postelems);

            if (typeof container.iso !== "undefined") {
                container.iso.prepended(postselems);
            }

            imagesLoaded(container, function() {
                $('.transaparent-isotope').toggleClass('transaparent-isotope');

                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }

                WallData.replace(posts, index+1, replaceId);
            });
        },

        appendOver: function() {
            loadedCount = WallData.loadCount;
            WallData.loadCount = 0;
            WallData.loadInProgress = false;
            if (WallData.appendFinishCallback) {
                WallData.appendFinishCallback(loadedCount);
            }
        },

        prependOver: function() {
            WallData.prependInProgress = false;
            if (WallData.prependFinishCallback) {
                WallData.prependFinishCallback();
            }
        },

        replaceOver: function() {
            WallData.replaceInProgress = false;
            if (WallData.replaceFinishCallback) {
                WallData.replaceFinishCallback();
            }
        },

        appendBegin: function() {
            WallData.appendId++;
            WallData.loadCount = 0;
            WallData.loadInProgress = true;
            if (WallData.appendStartCallback) {
                WallData.appendStartCallback();
            }
        },

        prependBegin: function() {
            WallData.prependInProgress = true;
            if (WallData.prependStartCallback) {
                WallData.prependStartCallback();
            }
        },

        replaceBegin: function() {
            WallData.replaceInProgress = true;
            if (WallData.replaceStartCallback) {
                WallData.replaceStartCallback();
            }
        },

        setAppendFinishCallback: function(cb) {
            WallData.appendFinishCallback = cb;
        },

        setAppendStartCallback: function(cb) {
            WallData.appendStartCallback = cb;
        },

        setPrependFinishCallback: function(cb) {
            WallData.prependFinishCallback = cb;
        },

        setReplaceFinishCallback: function(cb) {
            WallData.replaceFinishCallback = cb;
        },

        setPrependStartCallback: function(cb) {
            WallData.prependStartCallback = cb;
        },

        setReplaceStartCallback: function(cb) {
            WallData.replaceStartCallback = cb;
        },

        iframelistener: function(e){
            if ( e.data.hasOwnProperty("loadMorePosts") ) {
                var h = Number( e.data["loadMorePosts"] );
                if (h) {
                    if (!WallData.isLoadOnScrollEnabled() || WallData.ignoreParentScroll() ) {
                        return;
                    }
                    WallData.appendMorePosts();
                }
            }
            else if ( e.data.hasOwnProperty("windowResize") ) {
                var r = Number( e.data["windowResize"] );
                if (r) {
                    WallData.setBannerHeight();
                    if (WallData.onResizeCallback) {
                        WallData.onResizeCallback();
                    }

                    // for isotope based layouts, re-arrange
                    for (var i=0; i<total_grid_columns; i++) {
                        var container = document.querySelector('#postgrid-'+i);
                        if (container && typeof container.iso != "undefined" ){
                            container.iso.layout();
                        }
                    }
                    if (WallData.auto_resize_enabled) {
                        window.parent.postMessage({ resize_height: $('body').outerHeight( true ) }, current_parent_location);
                    }
                }
            }
            else if ( e.data.hasOwnProperty("getPostAt") ) {
                var p = Number( e.data["getPostAt"] );
                if (p) {
                    var d = Number( e.data["getPostAtDirection"] );
                    WallData.getPostAt(p, d);
                }
            }
            else if ( e.data.hasOwnProperty("view_post") ) {
                 $('.wallpost-slide').html('');

                 var post = e.data["view_post"];
                 var options = e.data["view_post_options"];
                 if (post) {
                    if (options && options.hide_contorls) {
                        $('.social-media-wall-prev-next-button.next').removeClass('show').addClass('hide');
                        $('.social-media-wall-prev-next-button.previous').removeClass('show').addClass('hide');
                        $('.modal-close').removeClass('show').addClass('hide');
                    } else {
                        $('.social-media-wall-prev-next-button.next').removeClass('hide').addClass('show');
                        $('.social-media-wall-prev-next-button.previous').removeClass('hide').addClass('show');
                        $('.modal-close').removeClass('hide').addClass('show');
                    }
                    $('.social-media-wall-prev-next-button.next').prop('disabled', false);
                    $('.social-media-wall-prev-next-button.previous').prop('disabled', false);
                    var posts = [];
                    var elemId = '#wallpost-slide';
                    posts.push(post);
                    WallData.CurrentSlidePostId = post.postid;
                    WallData.getValidPosts(posts, WallData.fillPostSlideValid, {"elemId":elemId, "cb":WallData.showPostSlideValid});
                    if (!options || options["ignore_ga"] != "true") {
                        if (typeof GAEvent != "undefined") {
                            GAEvent(post.postid);
                        }
                    }
                 } else {
                    var elemId = '#wallpost-slide';
                 }
             }
             else if ( e.data.hasOwnProperty("hide_view_post") ) {
                var hidepost = e.data["hide_view_post"];
                $('.wallpost-slide').html('');
                if ($('#wallpost-modal').length > 0) {
                    $('#wallpost-modal').modal('hide');
                    $('#wallpost-modal').hide();
                }
             }
             else if ( e.data.hasOwnProperty("get_next_slide_post") ) {
                var postid = e.data["get_next_slide_post"];
                var elemId = "#wallpost-slide"
                WallData.getPostAfterId(elemId, postid);
             }
             else if ( e.data.hasOwnProperty("get_prev_slide_post") ) {
                var postid = e.data["get_prev_slide_post"];
                var elemId = "#wallpost-slide"
                WallData.getPostBeforeId(elemId, postid);
             }
             else if ( e.data.hasOwnProperty("host_url_check") ) {
                var host_url = e.data["host_url_check"];
                WallData.hostUrlCheck(host_url);
             }
        },
        addListener: function() {
            if (window.addEventListener){
                addEventListener("message", WallData.iframelistener, false)
            } else {
                attachEvent("onmessage", WallData.iframelistener)
            }
        },

        setBackgroundImage: function(imageurl) {
            if (!imageurl) {
                return;
            }
            function loadBgImage(url){
                var img = new Image();
                img.onload = function(){
                    if ($('.wall-embed').length > 0) {
                        var url = "url('";
                        url += imageurl;
                        url += "')";
                        $('body').css("background-image", url);
                    }
                };
                img.onerror = function() {
                    if (current_display_internal) {
                        bootbox.dialog({
                            closeButton: false,
                            title: '<i class="fa fa-info-circle" style="margin-right:3px;color:blue"></i>Background image was not found',
                            message: '<span style="font-size: 1em;">Failed to load specified background image. Please verify URL of background image.</span>',
                            buttons: {
                              yes: {
                                label: "OK",
                                callback: function() {
                                }
                              }
                            }
                        });
                    }
                };
                img.src = url;
            }
            loadBgImage(imageurl);
        },

        setBannerImage: function(imageurl, cb) {
            if (!imageurl) {
                cb();
                return;
            }
            function getMeta(url){
                var img = new Image();
                function loadHandler(height, width) {
                    var image_val = "url('";
                    image_val += url;
                    image_val += "')";
                    $('#wall-banner-image').css("background-image", image_val);

                    setTimeout(function(){ WallData.setBannerHeight();}, 500);
                    setTimeout(function(){ WallData.setBannerHeight();}, 3000);
                    cb();
                }
                img.onload = function(){
                    loadHandler(this.height, this.width);
                };
                img.onerror = function() {
                    if (current_display_internal) {
                        bootbox.dialog({
                            closeButton: false,
                            title: '<i class="fa fa-info-circle" style="margin-right:3px;color:blue"></i>Banner image was not found',
                            message: '<span style="font-size: 1em;">Failed to load specified banner image. Please verify URL of banner image.</span>',
                            buttons: {
                              yes: {
                                label: "OK",
                                callback: function() {
                                }
                              }
                            }
                        });
                    }
                    cb();
                };
                img.src = url;
                if (img.complete) {
                    loadHandler(img.height, img.width);
                }
            }
            getMeta(imageurl);
        },

        setBannerText: function(bannertitle, bannertext, websiteurltext, twitterfollow, instagramview, facebookfollow, googlepluspage) {
            if (!bannertitle && !bannertext && !twitterfollow && !instagramview && !facebookfollow && !googlepluspage && !websiteurltext) {
                return;
            }
            banner_overlap_markup = '<div class="wall-banner-overlap" id="wall-banner-overlap">';
            if (bannertitle) {
                banner_overlap_markup += '<p class="wall-banner-overlap-title"></p>';
            }
            if (bannertext) {
                banner_overlap_markup += '<span class="wall-banner-overlap-text"></span>';
            }
            if (websiteurltext) {
                banner_overlap_markup += '<a target="_blank" rel="nofollow" class="wall-banner-overlap-websiteurl" href=""><i class="fa fa-globe" style="margin: 3px" ></i><span class="wall-banner-overlap-websiteurltext"></span></a>';
            }
            if (twitterfollow  || instagramview || facebookfollow || googlepluspage) {
                banner_overlap_markup += '<div class="text-center wall-banner-social-icons">';
                banner_overlap_markup += '<div class="btn-group wall-banner-overlap-btn-group" id="wall-banner-overlap-btn-group">';
                if (twitterfollow) {
                    twitteraccounts = twitterfollow.split(',');
                    for (var i=0; i<twitteraccounts.length; ++i) {
                        banner_overlap_markup += '<a class="social-icon-wrapper" style="margin: 3px" target="_blank" rel="nofollow" href="https://www.twitter.com/' + twitteraccounts[i] + '" title="' + twitteraccounts[i] + '"><i class="fa fa-twitter wall-twitter-color"></i></a>';
                    }
                }
                if (instagramview) {
                    instagramaccounts = instagramview.split(',');
                    for (var i=0; i<instagramaccounts.length; ++i) {
                        banner_overlap_markup += '<a class="social-icon-wrapper" style="margin: 3px" target="_blank" rel="nofollow" href="https://www.instagram.com/' + instagramaccounts[i] + '" title="' + instagramaccounts[i] + '"><i class="fa fa-instagram wall-instagram-color"></i></a>';
                    }
                }
                if (facebookfollow) {
                    facebookaccounts = facebookfollow.split(',');
                    for (var i=0; i<facebookaccounts.length; ++i) {
                        banner_overlap_markup += '<a class="social-icon-wrapper" style="margin: 3px" target="_blank" rel="nofollow" href="https://www.facebook.com/' + facebookaccounts[i] + '" title="' + facebookaccounts[i] + '"><i class="fa fa-facebook wall-facebook-color"></i></a>';
                    }
                }
                if (googlepluspage) {
                    googleplusaccounts = googlepluspage.split(',');
                    for (var i=0; i<googleplusaccounts.length; ++i) {
                        banner_overlap_markup += '<a class="social-icon-wrapper" style="margin: 3px" target="_blank" rel="nofollow" href="https://plus.google.com/' + googleplusaccounts[i] + '" title="' + googleplusaccounts[i] + '"><i class="fa fa-google-plus wall-google-plus-color"></i></a>';
                    }
                }
                banner_overlap_markup += '</div>';
                banner_overlap_markup += '</div>';
            }

            banner_overlap_markup += '</div>';


            $('#wall-banner').append(banner_overlap_markup);

            if (bannertitle) {
                var jqTextNode = $(document.createTextNode(bannertitle));
                $('.wall-banner-overlap-title').html(jqTextNode.text());
            }
            if (bannertext) {
                var jqTextNode = $(document.createTextNode(bannertext));
                $('.wall-banner-overlap-text').html(jqTextNode.text());
            }
            if (websiteurltext) {
                var jqTextNode = $(document.createTextNode(websiteurltext));
                $('.wall-banner-overlap-websiteurltext').html(jqTextNode.text());
                $('.wall-banner-overlap-websiteurl').attr('href', jqTextNode.text());
            }
        },

        setBannerHeight: function() {
            if ($('#wall-banner').length <= 0) {
                return;
            }
            textheight = 0;
            if ($('#wall-banner-overlap').length > 0) {
                textheight = $('#wall-banner-overlap').outerHeight(true);
                if ($('#wall-banner-overlap-btn-group').length > 0) {
                    textheight += $('#wall-banner-overlap-btn-group').outerHeight(true);
                }
            }
            sliderheight = 0;
            if ($('.wall-banner-slideshow').length > 0) {
                sliderheight = $('.wall-banner-slideshow').outerHeight(true);
            }
            resultheight = $('#wall-banner-image').outerHeight(true);
            resultheight = Math.max(resultheight, textheight);
            resultheight = Math.max(resultheight, sliderheight);
            currentHeight = $('#wall-banner').height();
            if (Math.abs(resultheight - currentHeight) > 10) {
                $('#wall-banner').css("height", resultheight + 'px');
            }
        },

        setCustomCss: function(css) {
            var style = "<style>";
            style += css;
            style += "</style>";
            $( "head" ).append(style);
        },

        getCurrentGridId: function() {
            return current_grid_column;
        },

        getGridId: function() {
            current_grid_column = (current_grid_column + 1) %  total_grid_columns;
            return '#postgrid-'+current_grid_column;
        },

        initPostGridWithoutHtml: function(totalGrids) {
            current_grid_column = totalGrids - 1;
            total_grid_columns = totalGrids;

            grids = [];

            for (var i=0; i<totalGrids; i++) {
                gridposts = [];
                grids.push(gridposts);
            }
        },

        initPostFlick: function(totalGrids) {
            current_grid_column = totalGrids - 1;
            total_grid_columns = totalGrids;

            gridmarkup = '';
            for (var i=0; i<totalGrids; i++) {
                gridposts = [];
                grids.push(gridposts);
                gridmarkup += '<div class="wallitem-slider" id="wallitem-slider-';
                gridmarkup += i;
                gridmarkup += '" >';
                gridmarkup += '<div class="wallitem-container" id="postgrid-';
                gridmarkup += i;
                gridmarkup += '" ></div>';
                gridmarkup += '</div>';
            }
            $('#wall-wrapper').prepend(gridmarkup);
        },
        initPostSlideShow: function(totalGrids) {
            current_grid_column = totalGrids - 1;
            total_grid_columns = totalGrids;

            gridmarkup = '';
            for (var i=0; i<totalGrids; i++) {
                gridposts = [];
                grids.push(gridposts);
                gridmarkup += '<div class="wallitem-slider" id="wallitem-slider-';
                gridmarkup += i;
                gridmarkup += '" >';
                gridmarkup += '<div class="wallitem-container master" id="postgrid-';
                gridmarkup += i;
                gridmarkup += '" ></div>';
                gridmarkup += '</div>';
            }
            $('#wall-wrapper').append(gridmarkup);
        },
        initPostImageGrid: function(totalGrids) {
            current_grid_column = totalGrids - 1;
            total_grid_columns = totalGrids;
            WallData.postImageGrid = true;
            gridposts = [];
            grids.push(gridposts);
        },
        initPostGrid: function(totalGrids) {
            current_grid_column = totalGrids - 1;
            total_grid_columns = totalGrids;

            gridmarkup = '';
            for (var i=0; i<totalGrids; i++) {
                gridposts = [];
                grids.push(gridposts);
                gridmarkup += '<div class="wallitem-slider" id="wallitem-slider-';
                gridmarkup += i;
                gridmarkup += '" >';
                gridmarkup += '<div class="wallitem-container isotope master" id="postgrid-';
                gridmarkup += i;
                gridmarkup += '" ></div>';
                gridmarkup += '</div>';
            }
            $('#wall-wrapper').prepend(gridmarkup);
        },
        initVideoPlayer: function() {
            videoplayermarkup = '<div class="grid-sizer"></div>';
            videoplayermarkup += '<div class="wallitem wallitem-video-player">';

            videoplayermarkup += '<div class="wallpost-video" id="wallpost-video">';
            videoplayermarkup += '<div class="embed-video-container" id="embed-video-container">';

            videoplayermarkup += '</div>';
            videoplayermarkup += '</div>';
            videoplayermarkup += '</div>';

            var gridid = '#postgrid-0';
            var container = document.querySelector(gridid);
            var contents = $('<div/>').html(videoplayermarkup).contents();

            $(gridid).append(contents);

            var container = document.querySelector(gridid);
            if ( container ) {

                if (typeof container.iso !== "undefined") {
                    container.iso.appended(contents);
                    container.iso.layout();
                }
                if (WallData.auto_resize_enabled) {
                    window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
                }
            }
        },
        resizeViewToFitElements: function() {
            window.parent.postMessage({ if_height: $('body').outerHeight( true ) }, current_parent_location);
        },
        playVideo: function(videoUrl) {
           if (!document.getElementById('embed-video-container')) {
                return;
           }

           if (videoUrl.indexOf("youtube.com") > -1) {
                   var video_id = videoUrl.split('v=')[1];
                   var ampersandPosition = video_id.indexOf('&');
                   if(ampersandPosition != -1) {
                      video_id = video_id.substring(0, ampersandPosition);
                   }
                   var videomarkup = '<iframe src="';
                   videomarkup += 'https://www.youtube.com/embed/' + video_id;
                   videomarkup += '?autoplay=1&rel=0';
                   videomarkup += '" frameborder="0" allowfullscreen></iframe>';
                   document.getElementById('embed-video-container').innerHTML = unescape(videomarkup);
           } else if (videoUrl.indexOf("vimeo.com") > -1) {
                   var embedpostlink = videoUrl;
                   embedpostlink = embedpostlink.replace("//vimeo.com/", "//player.vimeo.com/video/")
                   var videomarkup = '<iframe src="';
                   videomarkup += embedpostlink
                   videomarkup += '?autoplay=1';
                   videomarkup += '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
                   document.getElementById('embed-video-container').innerHTML = unescape(videomarkup);
            } else if (videoUrl.indexOf("vine.co") > -1) {
                   var videomarkup = '<iframe src="';
                   videomarkup += videoUrl;
                   videomarkup += '/card?audio=1" frameborder="0" " webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe><script src="https://platform.vine.co/static/scripts/embed.js"></script>';
                   document.getElementById('embed-video-container').innerHTML = unescape(videomarkup);
            }
        },
    }
}();

function getPostSlideHeaderMarkup(postobj) {
    var user_src_href = WallCommon.getUserLink(postobj);
    var post_src_href = WallCommon.getPostLink(postobj);
    var post_source_icon = WallCommon.getPostNetworkIcon(postobj);
    var source_color = WallCommon.getNetworkColor(postobj);
    var post_source_color = WallCommon.getPostNetworkColor(postobj);

    var postmarkup = '';

    postmarkup += '<header class="modern">';
    postmarkup += '<span class="wall-publisher-profile">';

    postmarkup += '<img src="';
    postmarkup += postobj.authorimage;
    postmarkup += '" onerror="this.src=\'';
    postmarkup += '//static.socialmediawall.io/';
    postmarkup += 'images/emptyface.jpg\'">';

    postmarkup += '<i class="network-icon fa fa-comment ';
    postmarkup += source_color;
    postmarkup += '"><i class="network-icon-inner ';
    postmarkup += post_source_icon;
    postmarkup += ' ';
    postmarkup += post_source_color;
    postmarkup += '"></i>';


    postmarkup += '</i></i></span><a rel="nofollow" href="';
    postmarkup += user_src_href
    postmarkup += '" class="publisher-display" target="_blank">';

    authorname = postobj.author_display_name;
    if (!authorname) {
        authorname = postobj.authorname;
    }

    var cleanauthorname = sanitizeHtml(authorname, {
        allowedTags: [ 'a' ],
        allowedAttributes: {
          'a': [ 'href', 'target', 'rel' ]
        }
      }
    );

    postmarkup += cleanauthorname;
    postmarkup += '</a>';
    postmarkup += '<div class="publisher-timestamp">'

    postmarkup += '<a rel="nofollow" href="';
    postmarkup += user_src_href;
    postmarkup += '" class="publisher" target="_blank">';

    cleanauthorname = sanitizeHtml(postobj.authorname, {
        allowedTags: [ 'a' ],
        allowedAttributes: {
          'a': [ 'href', 'target', 'rel' ]
        }
      }
    );
    postmarkup += cleanauthorname;
    postmarkup += '</a>';
    postmarkup += '<a rel="nofollow" href="';
    postmarkup += post_src_href;
    postmarkup += '" class="post-timestamp" target="_blank">';

    postmarkup += '<span data-livestamp=';
    postmarkup += postobj.creationtime;
    postmarkup += '>';
    postmarkup += '</span>';
    postmarkup += '</a></div>';
    postmarkup += '</header>';

    return postmarkup;
}
function getPostHeaderMarkupOverlay(postobj) {
    var user_src_href = WallCommon.getUserLink(postobj);
    var post_src_href = WallCommon.getPostLink(postobj);
    var post_source_icon = WallCommon.getPostNetworkIcon(postobj);
    var post_source_color = WallCommon.getPostNetworkColor(postobj);
    var source_color = WallCommon.getNetworkColor(postobj);
    var postmarkup = '';
    var highlighted_post = isPostHighlighted(postobj);
    var postHeaderStyle = highlighted_post ? WallData.getHlPostHeaderStyle() : WallData.getPostHeaderStyle();
    var postHeaderPosition = highlighted_post ? WallData.getHlPostHeaderPosition() : WallData.getPostHeaderPosition();
    postmarkup += '<header class="classic">';
    postmarkup += '<aside class="user-thumb wall-publisher-profile" style="background-image: url(\'';
    postmarkup += postobj.authorimage;
    postmarkup += '\'); ">';
    postmarkup += '</aside>';

    postmarkup += '<aside class="post-icon-and-time ';
    postmarkup += ' post-icon-and-time-top '

    postmarkup += '">';

    postmarkup += '<span class="timestamp">';
    postmarkup += '<span data-livestamp=';
    postmarkup += postobj.creationtime;
    postmarkup += '>';
    postmarkup += '</span>';
    postmarkup += '</span> ';

    postmarkup += '<span class="network-icon social-icon-wrapper wx-network-icon wx-';
    postmarkup += postobj.source;
    postmarkup += '-icon-wrapper"> <i class="';
    postmarkup += post_source_icon;
    postmarkup += ' ';
    postmarkup += post_source_color;
    postmarkup += '"></i></span>';

    postmarkup += '</aside>';

    postmarkup += '<div class="publisher-display">';

    authorname = postobj.author_display_name;
    if (!authorname) {
        authorname = postobj.authorname;
    }

    var cleanauthorname = sanitizeHtml(authorname, {
        allowedTags: [ ],
        allowedAttributes: {

        }
      }
    );
    postmarkup += cleanauthorname;

    postmarkup += '</div>';



    postmarkup += '<div class="publisher">';

    postmarkup += '<span>';

    cleanauthorname = sanitizeHtml(postobj.authorname, {
        allowedTags: [ ],
        allowedAttributes: {

        }
      }
    );
    postmarkup += cleanauthorname;

    postmarkup += '</span> ';
    postmarkup += '</div>';





    postmarkup += '</header>';
    return postmarkup;
}
function getPostHeaderMarkup(postobj) {


    var user_src_href = WallCommon.getUserLink(postobj);
    var post_src_href = WallCommon.getPostLink(postobj);
    var post_source_icon = WallCommon.getPostNetworkIcon(postobj);
    var post_source_color = WallCommon.getPostNetworkColor(postobj);
    var source_color = WallCommon.getNetworkColor(postobj);
    var postmarkup = '';
    var highlighted_post = isPostHighlighted(postobj);
    var postHeaderStyle = highlighted_post ? WallData.getHlPostHeaderStyle() : WallData.getPostHeaderStyle();
    var postHeaderPosition = highlighted_post ? WallData.getHlPostHeaderPosition() : WallData.getPostHeaderPosition();

    if (postHeaderStyle == 'classic') {
        postmarkup += '<header class="classic">';

        postmarkup += '<aside class="user-thumb wall-publisher-profile">';

        postmarkup += '<a href="';
        postmarkup += user_src_href;
        postmarkup += '" target="_blank">';

        postmarkup += '<img src="';

        postmarkup += postobj.authorimage;
        postmarkup += '" onerror="this.src=\'';
        postmarkup += '//static.socialmediawall.io/';
        postmarkup += 'images/emptyface.jpg\'">';
        postmarkup += '</aside>';




        postmarkup += '<div class="publisher-display">';

        authorname = postobj.author_display_name;
        if (!authorname) {
            authorname = postobj.authorname;
        }

        var cleanauthorname = sanitizeHtml(authorname, {
            allowedTags: [ 'a' ],
            allowedAttributes: {
              'a': [ 'href', 'target', 'rel' ]
            }
          }
        );
        postmarkup += cleanauthorname;

        postmarkup += '</div>';

        postmarkup += '<div class="publisher">';

        postmarkup += '<a href="';
        postmarkup += user_src_href;
        postmarkup += '" target="_blank">';

        cleanauthorname = sanitizeHtml(postobj.authorname, {
            allowedTags: [ 'a' ],
            allowedAttributes: {
              'a': [ 'href', 'target', 'rel' ]
            }
          }
        );
        postmarkup += cleanauthorname;

        postmarkup += '</a> ';
        postmarkup += '</div>';

        postmarkup += '<div class="post-icon-and-time ';
        if (postHeaderPosition == 'top') {
            postmarkup += ' post-icon-and-time-top '
        } else if (postHeaderPosition == 'bottom') {
            postmarkup += ' post-icon-and-time-bottom '
        }

        postmarkup += '">';

        postmarkup += '<a href="';
        postmarkup += post_src_href;
        postmarkup += '" target="_blank">';
        postmarkup += '<span data-livestamp=';
        postmarkup += postobj.creationtime;
        postmarkup += '>';
        postmarkup += '</span>';
        postmarkup += '</a> ';

        postmarkup += '<span class="network-icon social-icon-wrapper wx-network-icon wx-';
        postmarkup += postobj.source;
        postmarkup += '-icon-wrapper"> <i class="';
        postmarkup += post_source_icon;
        postmarkup += ' ';
        postmarkup += post_source_color;
        postmarkup += '"></i></span>';

        postmarkup += '</div>';


        postmarkup += '</header>';
    } else if (postHeaderStyle == 'modern') {
        postmarkup += '<header class="modern">';
        postmarkup += '<span class="wall-publisher-profile">';

        postmarkup += '<img src="';
        postmarkup += postobj.authorimage;
        postmarkup += '" onerror="this.src=\'';
        postmarkup += '//static.socialmediawall.io/';
        postmarkup += 'images/emptyface.jpg\'">';

        postmarkup += '<i class="network-icon fa fa-comment ';
        postmarkup += source_color;
        postmarkup += '"><i class="network-icon-inner ';
        postmarkup += post_source_icon;
        postmarkup += ' ';
        postmarkup += post_source_color;
        postmarkup += '"></i>';


        postmarkup += '</i></i></span><a rel="nofollow" href="';
        postmarkup += user_src_href
        postmarkup += '" class="publisher-display" target="_blank">';

        authorname = postobj.author_display_name;
        if (!authorname) {
            authorname = postobj.authorname;
        }

        var cleanauthorname = sanitizeHtml(authorname, {
            allowedTags: [ 'a' ],
            allowedAttributes: {
              'a': [ 'href', 'target', 'rel' ]
            }
          }
        );

        postmarkup += cleanauthorname;
        postmarkup += '</a>';
        postmarkup += '<div class="publisher-timestamp">'

        postmarkup += '<a rel="nofollow" href="';
        postmarkup += user_src_href;
        postmarkup += '" class="publisher" target="_blank">';

        cleanauthorname = sanitizeHtml(postobj.authorname, {
            allowedTags: [ 'a' ],
            allowedAttributes: {
              'a': [ 'href', 'target', 'rel' ]
            }
          }
        );
        postmarkup += cleanauthorname;
        postmarkup += '</a>';
        postmarkup += '<a rel="nofollow" href="';
        postmarkup += post_src_href;
        postmarkup += '" class="post-timestamp" target="_blank">';

        postmarkup += '<span data-livestamp=';
        postmarkup += postobj.creationtime;
        postmarkup += '>';
        postmarkup += '</span>';
        postmarkup += '</a></div>';
        postmarkup += '</header>';
    }  else if (postHeaderStyle == 'compact') {
        postmarkup += '<header class="compact">';
        postmarkup += '<span class="wall-publisher-profile">';

        postmarkup += '<img src="';
        postmarkup += postobj.authorimage;
        postmarkup += '" onerror="this.src=\'';
        postmarkup += '//static.socialmediawall.io/';
        postmarkup += 'images/emptyface.jpg\'">';

        postmarkup += '</span>';

        postmarkup += '<i class="network-icon ';
        postmarkup += post_source_icon;
        postmarkup += ' ';
        postmarkup += post_source_color;
        postmarkup += '"></i>';


        postmarkup += '<a rel="nofollow" href="';
        postmarkup += user_src_href
        postmarkup += '" class="publisher-display" target="_blank">';

        authorname = postobj.author_display_name;
        if (!authorname) {
            authorname = postobj.authorname;
        }

        var cleanauthorname = sanitizeHtml(authorname, {
            allowedTags: [ 'a' ],
            allowedAttributes: {
              'a': [ 'href', 'target', 'rel' ]
            }
          }
        );

        postmarkup += cleanauthorname;
        postmarkup += '</a>';


        postmarkup += '<a rel="nofollow" href="';
        postmarkup += post_src_href;
        postmarkup += '" class="post-timestamp" target="_blank">';

        postmarkup += '<span data-livestamp=';
        postmarkup += postobj.creationtime;
        postmarkup += '>';
        postmarkup += '</span>';
        postmarkup += '</a>';
        postmarkup += '</header>';
    }
    return postmarkup;
}

function getPostSlideMarkup(postobj, videoautoplay, stylestr) {
    var post_src_href = WallCommon.getPostLink(postobj);
    var mediaExists = postobj.imagelink ? true : false;
    var textExists = false;

    var comment = postobj.text;
    var comment_prefix = ''
    var comment_suffix = ''
    var comment_title = '';
    var inreply = false;
    var isretweet = false;
    var highlighted_post = isPostHighlighted(postobj);
    if (postobj.postinfo) {
        var post_info_obj = JSON.parse(postobj.postinfo);
        if (post_info_obj && post_info_obj.retweet == 'true') {
            isretweet = true;
        }
        if (post_info_obj && post_info_obj.prefix_text) {
            comment_prefix = post_info_obj.prefix_text;
            if (post_info_obj.inreply == 'true') {
                inreply = true;
            }
        }
        if (post_info_obj && post_info_obj.display_text) {
            comment = post_info_obj.display_text
        }
        if (post_info_obj && post_info_obj.suffix_text) {
            comment_suffix = post_info_obj.suffix_text;
        }
        if (post_info_obj && post_info_obj.display_text_title) {
            comment_title = post_info_obj.display_text_title
        }
    }

    var headerAttached = false;

    var postmarkup = '';
        postmarkup += '<div class="postslide ';
        if (isPostHighlighted(postobj)) {
            postmarkup += ' ' + 'postslide-highlight ';
        }
        postmarkup += ' row">';
        if (mediaExists || WallData.defaultpostimage) {
            postmarkup += '<div class="slide-left col-xs-12 col-sm-12 col-md-6 col-lg-6">';
        } else {
            postmarkup += '<div class="slide-center col-xs-12 col-sm-12 col-md-offset-3 col-md-6 col-lg-offset-3 col-lg-6">';
        }
        postmarkup += '<div class="post-header">';
        postmarkup += getPostSlideHeaderMarkup(postobj);
        postmarkup += '</div>';

        headerAttached = true;
        if (comment_title || comment) {



            postmarkup += '<div class="post-text">';

            textExists = true;
            postmarkup += '<div class="wallpost-text">';

            if (comment_title) {
                postmarkup += '<span class="wallpost-text-title">';
                postmarkup += '<a target="blank" rel="nofollow" href="';
                postmarkup += post_src_href;
                postmarkup += '">';
                var clean_title = sanitizeHtml(comment_title, {
                    allowedTags: [ 'a' ],
                    allowedAttributes: {
                      'a': [ 'href', 'target', 'rel' ]
                    }
                  }
                );
                postmarkup += clean_title;
                postmarkup += '</a>';
                postmarkup += '</span>';
                postmarkup += '<br>';
            }

            if (comment_prefix) {
                postmarkup += '<span class="wallpost-text-prefix">';
                if (inreply) {
                    postmarkup += '<i class="fa fa-reply"></i>In reply to '
                } else if (isretweet) {
                    postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
                }
                postmarkup += comment_prefix;
                postmarkup += '</span>';
                postmarkup += '<br>';
            } else if (isretweet) {
                postmarkup += '<span class="wallpost-text-prefix">';
                postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
                postmarkup += '</span>';
                postmarkup += '<br>';
            }

            comment = linkifyHtml(comment);

            postmarkup += '<span>';
            if (comment) {
                var clean = sanitizeHtml(comment, {
                    allowedTags: [],
                    allowedAttributes: []
                  }
                );

                var posttextsize = highlighted_post ? WallData.getHlPostTextSize() : WallData.getPostTextSize();

                if (posttextsize && posttextsize > 0 && posttextsize < clean.length) {
                    clean = clean.substring(0, posttextsize) + '...';
                }
                else {
                  clean = sanitizeHtml(comment, {
                        allowedTags: [ 'a' ],
                        allowedAttributes: {
                          'a': [ 'href', 'target', 'rel' ]
                        }
                    }
                  );
                }
                postmarkup += clean;
            }
            postmarkup += '</span>';

//            if (comment_suffix) {
//                postmarkup += '<br>';
//                postmarkup += '<span class="wallpost-text-suffix">';
//                //postmarkup += comment_suffix;
//                postmarkup += '</span>';
//            }

            postmarkup += '</div>';
            postmarkup += '</div>';

       }
       postmarkup += '</div>';


       if (mediaExists  || WallData.defaultpostimage) {
           var postimageurl = mediaExists ? postobj.imagelink : WallData.defaultpostimage;
           postmarkup += '<div class="slide-right col-xs-12 col-sm-12 col-md-6 col-lg-6">';

           if (postobj.source == "youtube") {
               var video_id = postobj.sourceid;
               var videomarkup = '<iframe width="100%" height="100%" id="yt-post-media" src="';
               videomarkup += 'https://www.youtube.com/embed/' + video_id;
               videomarkup += '?rel=0';
               if (videoautoplay) {
                videomarkup += '&autoplay=1&volume="0"';
               }
               videomarkup += '" frameborder="0" allowfullscreen allow="autoplay; fullscreen"></iframe>';

               postmarkup += '<div class="post-media post-video" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<div class="embed-video-container">';
               postmarkup += unescape(videomarkup);
               postmarkup += '</div>';
               postmarkup += '</div>';
           } else if (postobj.source == "vimeo") {
               var embedpostlink = WallCommon.getPostLink(postobj);
               embedpostlink = embedpostlink.replace("//vimeo.com/", "//player.vimeo.com/video/")
               if (videoautoplay) {
                embedpostlink += '?autoplay=1'
               }
               var videomarkup = '<iframe width="100%" height="100%" src="';
               videomarkup += embedpostlink
               videomarkup += '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen allow="autoplay; fullscreen"></iframe>';

               postmarkup += '<div class="post-media post-video" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<div class="embed-video-container">';
               postmarkup += unescape(videomarkup);
               postmarkup += '</div>';
               postmarkup += '</div>';
           }
           else if (postobj.videolink) {
               if (postobj.source == 'facebook') {
                   postmarkup += '<div class="post-media post-video" ';
                   postmarkup += ' style="width:100%;background-color:#000 !important;">';
                   postmarkup += '<div class="embed-video-container" style="padding-top:0px !important;">';

                   postmarkup += '<div class="facebook-embed-video-container" style="';
                   postmarkup += stylestr;
                   postmarkup += '">';
                   postmarkup += '<iframe src="https://www.facebook.com/plugins/video.php?href=';
                   postmarkup += encodeURIComponent(postobj.videolink);
                   postmarkup += '&show_text=0';
                   if (videoautoplay) {
                    postmarkup += '&autoplay=1';
                   }
                   postmarkup += '" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true" allow="autoplay; fullscreen"></iframe>';
                   postmarkup += '</div>';
                   postmarkup += '</div>';
                   postmarkup += '</div>';
               }
               else if (postobj.source == 'instagram') {
                   var videolink = postobj.videolink;
                   var videofile = videolink.split("?")[0]
                   if (videofile.endsWith('mp4')) {
                       postmarkup += '<div class="post-media post-video" ';
                       postmarkup += ' style="width:100%;">';
                       postmarkup += '<video muted loop ';
                       if (videoautoplay) {
                        postmarkup += ' autoplay ';
                       }
                       postmarkup += ' controls><source src="';
                       postmarkup += postobj.videolink;
                       postmarkup += '" type="video/mp4"></video>';
                       postmarkup += '</div>';
                       postmarkup += '</div>';
                   }
                   else {
                       postmarkup += '<div class="post-media post-image" ';
                       postmarkup += ' style="width:100%;">';
                       postmarkup += '<img class="post-media-img" src="'+ postimageurl +'"></img>'
                       postmarkup += '</div>';
                   }
               }
               else if (postobj.source == 'twitter') {
                    if (postobj.postinfo) {
                        var post_info_obj = JSON.parse(postobj.postinfo);
                        var videolink = postobj.videolink;
                        var videofile = videolink.split("?")[0]
                        if (videofile.endsWith('mp4')) {
                            postmarkup += '<div class="post-media post-video" ';
                           postmarkup += ' style="width:100%;">';
                           postmarkup += '<video muted loop ';
                           if (videoautoplay) {
                            postmarkup += ' autoplay ';
                           }
                           postmarkup += ' controls><source src="';
                           postmarkup += postobj.videolink;
                           postmarkup += '" type="video/mp4"></video>';
                           postmarkup += '</div>';
                           postmarkup += '</div>';
                        }
                        else if (post_info_obj && post_info_obj["mediatype"] == "video") {
                            postmarkup += '<div class="post-media post-video" ';
                            postmarkup += ' style="width:100%;">';
                            postmarkup += '<div class="embed-video-container">';
                            postmarkup += '<blockquote class="twitter-video" data-status="hidden" style="width:100%;height:100%" data-lang="en">';
                            postmarkup += '<a href="';
                            postmarkup += post_src_href;
                            postmarkup += '"></a>';
                            postmarkup += '</blockquote>';
                            postmarkup += '</div>';
                            postmarkup += '</div>';
                        } else if (post_info_obj && post_info_obj["mediatype"] == "animated_gif") {
                            if (postobj.videolink.endsWith('mp4')) {
                               postmarkup += '<div class="post-media post-video" ';
                               postmarkup += ' style="width:100%;">';
                               postmarkup += '<video muted loop ';
                               if (videoautoplay) {
                                postmarkup += ' autoplay ';
                               }
                               postmarkup += ' style="width:100%;height:auto;" controls><source src="';
                               postmarkup += postobj.videolink
                               postmarkup += '" type="video/mp4"></video>'
                               postmarkup += '</div>';
                           } else {
                               postmarkup += '<div class="post-media post-image" ';
                               postmarkup += ' style="width:100%;">';
                               postmarkup += '<img class="post-media-img" src="'+ postimageurl +'"></img>'
                               postmarkup += '</div>';
                           }
                        } else {
                           postmarkup += '<div class="post-media post-image" ';
                           postmarkup += ' style="width:100%;">';
                           postmarkup += '<img class="post-media-img" src="'+ postimageurl +'"></img>'
                           postmarkup += '</div>';
                        }
                    }
               }
           } else {
               postmarkup += '<div class="post-media post-image" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<img class="post-media-img" src="'+ postimageurl +'"></img>'
               postmarkup += '</div>';
           }
           postmarkup += '</div>';
       }

   postmarkup += '</div>';
   return postmarkup;
}

function getPostSlideMarkup2(postobj, videoautoplay, stylestr) {
    var post_src_href = WallCommon.getPostLink(postobj);
    var mediaExists = postobj.imagelink ? true : false;
    var textExists = false;

    var comment = postobj.text;
    var comment_prefix = ''
    var comment_suffix = ''
    var comment_title = '';
    var inreply = false;
    var isretweet = false;
    var highlighted_post = isPostHighlighted(postobj);
    if (postobj.postinfo) {
        var post_info_obj = JSON.parse(postobj.postinfo);
        if (post_info_obj && post_info_obj.retweet == 'true') {
            isretweet = true;
        }
        if (post_info_obj && post_info_obj.prefix_text) {
            comment_prefix = post_info_obj.prefix_text;
            if (post_info_obj.inreply == 'true') {
                inreply = true;
            }
        }
        if (post_info_obj && post_info_obj.display_text) {
            comment = post_info_obj.display_text
        }
        if (post_info_obj && post_info_obj.suffix_text) {
            comment_suffix = post_info_obj.suffix_text;
        }
        if (post_info_obj && post_info_obj.display_text_title) {
            comment_title = post_info_obj.display_text_title
        }
    }

    var headerAttached = false;

    var postmarkup = '';
        postmarkup += '<div class="postslide ';
        if (isPostHighlighted(postobj)) {
            postmarkup += ' ' + 'postslide-highlight ';
        }
        postmarkup += ' row">';

        postmarkup += '<div class="slide-center col-xs-12 col-sm-12 col-md-12 col-lg-12">';
        postmarkup += '<div class="post-header">';
        postmarkup += getPostSlideHeaderMarkup(postobj);
        postmarkup += '</div>';

        headerAttached = true;



       if (mediaExists) {
           if (postobj.source == "youtube") {
               var video_id = postobj.sourceid;
               var videomarkup = '<iframe width="100%" height="100%" id="yt-post-media" src="';
               videomarkup += 'https://www.youtube.com/embed/' + video_id;
               videomarkup += '?rel=0';
               if (videoautoplay) {
                videomarkup += '&autoplay=1&volume="0"';
               }
               videomarkup += '" frameborder="0" allowfullscreen allow="autoplay; fullscreen"></iframe>';

               postmarkup += '<div class="post-media post-video" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<div class="embed-video-container">';
               postmarkup += unescape(videomarkup);
               postmarkup += '</div>';
               postmarkup += '</div>';
           } else if (postobj.source == "vimeo") {
               var embedpostlink = WallCommon.getPostLink(postobj);
               embedpostlink = embedpostlink.replace("//vimeo.com/", "//player.vimeo.com/video/")
               if (videoautoplay) {
                embedpostlink += '?autoplay=1'
               }
               var videomarkup = '<iframe width="100%" height="100%" src="';
               videomarkup += embedpostlink
               videomarkup += '" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen allow="autoplay; fullscreen"></iframe>';

               postmarkup += '<div class="post-media post-video" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<div class="embed-video-container">';
               postmarkup += unescape(videomarkup);
               postmarkup += '</div>';
               postmarkup += '</div>';
           }
           else if (postobj.videolink) {
               if (postobj.source == 'facebook') {
                   postmarkup += '<div class="post-media post-video" ';
                   postmarkup += ' style="width:100%;background-color:#000 !important;">';
                   postmarkup += '<div class="embed-video-container" style="padding-top:0px !important;">';

                   postmarkup += '<div class="facebook-embed-video-container" style="';
                   postmarkup += stylestr;
                   postmarkup += '">';
                   postmarkup += '<iframe src="https://www.facebook.com/plugins/video.php?href=';
                   postmarkup += encodeURIComponent(postobj.videolink);
                   postmarkup += '&show_text=0';
                   if (videoautoplay) {
                    postmarkup += '&autoplay=1';
                   }
                   postmarkup += '" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allowFullScreen="true" allow="autoplay; fullscreen"></iframe>';
                   postmarkup += '</div>';
                   postmarkup += '</div>';
                   postmarkup += '</div>';
               }
               else if (postobj.source == 'instagram') {
                   var videolink = postobj.videolink;
                   var videofile = videolink.split("?")[0]
                   if (videofile.endsWith('mp4')) {
                       postmarkup += '<div class="post-media post-video" ';
                       postmarkup += ' style="width:100%;">';
                       postmarkup += '<video muted loop ';
                       if (videoautoplay) {
                        postmarkup += ' autoplay ';
                       }
                       postmarkup += ' controls><source src="';
                       postmarkup += postobj.videolink;
                       postmarkup += '" type="video/mp4"></video>';
                       postmarkup += '</div>';
                       postmarkup += '</div>';
                   }
                   else {
                       postmarkup += '<div class="post-media post-image" ';
                       postmarkup += ' style="width:100%;">';
                       postmarkup += '<img class="post-media-img" src="'+ postobj.imagelink +'"></img>'
                       postmarkup += '</div>';
                   }
               }
               else if (postobj.source == 'twitter') {
                    if (postobj.postinfo) {
                        var post_info_obj = JSON.parse(postobj.postinfo);
                        var videolink = postobj.videolink;
                        var videofile = videolink.split("?")[0]
                        if (videofile.endsWith('mp4')) {
                            postmarkup += '<div class="post-media post-video" ';
                           postmarkup += ' style="width:100%;">';
                           postmarkup += '<video muted loop ';
                           if (videoautoplay) {
                            postmarkup += ' autoplay ';
                           }
                           postmarkup += ' controls><source src="';
                           postmarkup += postobj.videolink;
                           postmarkup += '" type="video/mp4"></video>';
                           postmarkup += '</div>';
                           postmarkup += '</div>';
                        }
                        else if (post_info_obj && post_info_obj["mediatype"] == "video") {
                            postmarkup += '<div class="post-media post-video" ';
                            postmarkup += ' style="width:100%;">';
                            postmarkup += '<div class="embed-video-container">';
                            postmarkup += '<blockquote class="twitter-video" data-status="hidden" style="width:100%;height:100%" data-lang="en">';
                            postmarkup += '<a href="';
                            postmarkup += post_src_href;
                            postmarkup += '"></a>';
                            postmarkup += '</blockquote>';
                            postmarkup += '</div>';
                            postmarkup += '</div>';
                        } else if (post_info_obj && post_info_obj["mediatype"] == "animated_gif") {
                            if (postobj.videolink.endsWith('mp4')) {
                               postmarkup += '<div class="post-media post-video" ';
                               postmarkup += ' style="width:100%;">';
                               postmarkup += '<video muted loop ';
                               if (videoautoplay) {
                                postmarkup += ' autoplay ';
                               }
                               postmarkup += ' style="width:100%;height:auto;" controls><source src="';
                               postmarkup += postobj.videolink
                               postmarkup += '" type="video/mp4"></video>'
                               postmarkup += '</div>';
                           } else {
                               postmarkup += '<div class="post-media post-image" ';
                               postmarkup += ' style="width:100%;">';
                               postmarkup += '<img class="post-media-img" src="'+ postobj.imagelink +'"></img>'
                               postmarkup += '</div>';
                           }
                        } else {
                           postmarkup += '<div class="post-media post-image" ';
                           postmarkup += ' style="width:100%;">';
                           postmarkup += '<img class="post-media-img" src="'+ postobj.imagelink +'"></img>'
                           postmarkup += '</div>';
                        }
                    }
               }
           } else {
               postmarkup += '<div class="post-media post-image" ';
               postmarkup += ' style="width:100%;">';
               postmarkup += '<img class="post-media-img" src="'+ postobj.imagelink +'"></img>'
               postmarkup += '</div>';
           }
       }

       else if (comment_title || comment) {



            postmarkup += '<div class="post-text">';

            textExists = true;
            postmarkup += '<div class="wallpost-text">';

            if (comment_title) {
                postmarkup += '<span class="wallpost-text-title">';
                postmarkup += '<a target="blank" rel="nofollow" href="';
                postmarkup += post_src_href;
                postmarkup += '">';
                var clean_title = sanitizeHtml(comment_title, {
                    allowedTags: [ 'a' ],
                    allowedAttributes: {
                      'a': [ 'href', 'target', 'rel' ]
                    }
                  }
                );
                postmarkup += clean_title;
                postmarkup += '</a>';
                postmarkup += '</span>';
                postmarkup += '<br>';
            }

            if (comment_prefix) {
                postmarkup += '<span class="wallpost-text-prefix">';
                if (inreply) {
                    postmarkup += '<i class="fa fa-reply"></i>In reply to '
                } else if (isretweet) {
                    postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
                }
                postmarkup += comment_prefix;
                postmarkup += '</span>';
                postmarkup += '<br>';
            } else if (isretweet) {
                postmarkup += '<span class="wallpost-text-prefix">';
                postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
                postmarkup += '</span>';
                postmarkup += '<br>';
            }

            comment = linkifyHtml(comment);

            postmarkup += '<span>';
            if (comment) {
                var clean = sanitizeHtml(comment, {
                    allowedTags: [],
                    allowedAttributes: []
                  }
                );

                var posttextsize = highlighted_post ? WallData.getHlPostTextSize() : WallData.getPostTextSize();

                if (posttextsize && posttextsize > 0 && posttextsize < clean.length) {
                    clean = clean.substring(0, posttextsize) + '...';
                }
                else {
                  clean = sanitizeHtml(comment, {
                        allowedTags: [ 'a' ],
                        allowedAttributes: {
                          'a': [ 'href', 'target', 'rel' ]
                        }
                    }
                  );
                }
                postmarkup += clean;
            }
            postmarkup += '</span>';

//            if (comment_suffix) {
//                postmarkup += '<br>';
//                postmarkup += '<span class="wallpost-text-suffix">';
//                //postmarkup += comment_suffix;
//                postmarkup += '</span>';
//            }

            postmarkup += '</div>';
            postmarkup += '</div>';

       }
       postmarkup += '</div>';

   postmarkup += '</div>';
   return postmarkup;
}

function isPostHighlighted(postobj) {
    var flag = postobj.wallflag;
    return (flag & 8) ? true: false;
}

function getPostImageMarkup(postobj) {
    var post_src_href = WallCommon.getPostLink(postobj);
    var postmarkup = '';
    var comment = postobj.text;
    var comment_prefix = '';
    var comment_suffix = '';
    var comment_title = '';
    var inreply = false;
    var isretweet = false;

    var postimageurl = postobj.imagelink ? postobj.imagelink : WallData.defaultpostimage;

    var highlighted_post = isPostHighlighted(postobj);
    postmarkup += '<li><div class="grid-elem ';
    if (highlighted_post) {
        postmarkup += ' grid-elem-highlight ';
    }
    postmarkup += '"><img src="';
    postmarkup += postimageurl;
    postmarkup += '"/>';
    postmarkup += getPostHeaderMarkupOverlay(postobj);

    if (postobj.postinfo) {
        var post_info_obj = JSON.parse(postobj.postinfo);
        if (post_info_obj && post_info_obj.retweet == 'true') {
            isretweet = true;
        }
        if (post_info_obj && post_info_obj.prefix_text) {
            comment_prefix = post_info_obj.prefix_text;
            if (post_info_obj.inreply == 'true') {
                inreply = true;
            }
        }
        if (post_info_obj && post_info_obj.display_text) {
            comment = post_info_obj.display_text;
        }
        if (post_info_obj && post_info_obj.suffix_text) {
            comment_suffix = post_info_obj.suffix_text;
        }
        if (post_info_obj && post_info_obj.display_text_title) {
            comment_title = post_info_obj.display_text_title;
        }
    }

    postmarkup += '<div class="wallpost-essence">';

    if (comment_title || comment) {


        postmarkup += '<div class="wallpost-text">';


        if (comment_title) {
            postmarkup += '<span class="wallpost-text-title">';
            postmarkup += '<a target="blank" rel="nofollow" href="';
            postmarkup += post_src_href;
            postmarkup += '">';
            var clean_title = sanitizeHtml(comment_title, {
                allowedTags: [ 'a' ],
                allowedAttributes: {
                  'a': [ 'href', 'target', 'rel' ]
                }
              }
            );
            postmarkup += clean_title;
            postmarkup += '</a>';
            postmarkup += '</span>';
            postmarkup += '<br>';
        }

        if (comment_prefix) {
            postmarkup += '<span class="wallpost-text-prefix">';
            if (inreply) {
                postmarkup += '<i class="fa fa-reply"></i>In reply to '
            } else if (isretweet) {
                postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
            }
            postmarkup += comment_prefix;
            postmarkup += '</span>';
            postmarkup += '<br>';
        } else if (isretweet) {
            postmarkup += '<span class="wallpost-text-prefix">';
            postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
            postmarkup += '</span>';
            postmarkup += '<br>';
        }

        comment = linkifyHtml(comment);

        postmarkup += '<span>';
        if (comment) {
            var clean = sanitizeHtml(comment, {
                allowedTags: [],
                allowedAttributes: []
              }
            );

            var posttextsize = highlighted_post ? WallData.getHlPostTextSize() : WallData.getPostTextSize();

            if (posttextsize && posttextsize > 0 && posttextsize < clean.length) {
                clean = clean.substring(0, posttextsize) + '...';
            }
            else {
              clean = sanitizeHtml(comment, {
                    allowedTags: [ 'a' ],
                    allowedAttributes: {
                      'a': [ 'href', 'target', 'rel' ]
                    }
                }
              );
            }

            postmarkup += clean;
        }
        postmarkup += '</span>';

//        if (comment_suffix) {
//            postmarkup += '<br>';
//            postmarkup += '<span class="wallpost-text-suffix">';
//            postmarkup += comment_suffix;
//            postmarkup += '</span>';
//        }

        postmarkup += '</div>';
    }
    postmarkup += '</div>';
    postmarkup += '</div></li>';
    return postmarkup;
}

function getPostMarkup(postobj) {
    var post_src_href = WallCommon.getPostLink(postobj);

    var comment = postobj.text;
    var comment_prefix = '';
    var comment_suffix = '';
    var comment_title = '';
    var inreply = false;
    var isretweet = false;
    var highlighted_post = isPostHighlighted(postobj);
    if (postobj.postinfo) {
        var post_info_obj = JSON.parse(postobj.postinfo);
        if (post_info_obj && post_info_obj.retweet == 'true') {
            isretweet = true;
        }
        if (post_info_obj && post_info_obj.prefix_text) {
            comment_prefix = post_info_obj.prefix_text;
            if (post_info_obj.inreply == 'true') {
                inreply = true;
            }
        }
        if (post_info_obj && post_info_obj.display_text) {
            comment = post_info_obj.display_text;
        }
        if (post_info_obj && post_info_obj.suffix_text) {
            comment_suffix = post_info_obj.suffix_text;
        }
        if (post_info_obj && post_info_obj.display_text_title) {
            comment_title = post_info_obj.display_text_title;
        }
    }

    wallpostid = 'wallitem-' + postobj.postid;
    var postmarkup = '';
    postmarkup += '<div class="wallitem ';
    postmarkup += wallpostid;
    if (highlighted_post) {
        postmarkup += ' ' + 'wallitem-highlight ';
        postmarkup += ' ' + WallData.getHlMediaSize() + ' ';
    } else {
        postmarkup += ' ' + WallData.getMediaSize() + ' ';
    }
    var postHeaderPosition = highlighted_post ? WallData.getHlPostHeaderPosition() : WallData.getPostHeaderPosition();
    var postanimation = highlighted_post ? WallData.getHlPostAnimation() : WallData.getPostAnimation();
    if (postanimation) {
        postmarkup += ' ' + 'wallitem-' + postanimation;
    }
    postmarkup += ' transaparent-isotope';
    postmarkup += '">';

    postmarkup += '<div class="wallpost ';
    postmarkup += postobj.source;
    postmarkup += '">';

    if (postHeaderPosition == 'top') {
        postmarkup += getPostHeaderMarkup(postobj);
    }

    //postmarkup += '<div class="container">';

    postmarkup += '<div class="wallpost-essence">';
    postmarkup += '<a class=wallpost-essence-target href=';
    postmarkup += post_src_href;
    postmarkup += ' data-postid=';
    postmarkup += postobj.postid;
    postmarkup += '>'
    postmarkup += '<div class="parent">'
    postmarkup += '<div class="child">'
    postmarkup += '<i class="fa fa-search-plus" style="margin-right: 3px;"></i>Magnify'
    postmarkup += '</div>'
    postmarkup += '</div>'
    postmarkup += '</a>'


    if ( postobj.imagelink )
    {
        postmarkup += '<div class="wallpost-image">';
        if (WallData.getMediaSize() == 'autoheight') {
            postmarkup += '<img class="" src="';
            postmarkup += postobj.imagelink;
            postmarkup += '" width="100%">';
        } else {
            postmarkup += '<div class="wallpost-bg-img" style="background-image: url(\'';
            postmarkup += postobj.imagelink;
            postmarkup += '\'); ">';
            postmarkup += '</div>';
        }
        if (postobj.videolink || postobj.source == 'vimeo' || postobj.source == 'youtube') {
            postmarkup += '<svg class="video-overlay-play-button" viewBox="0 0 150 150"><circle fill="rgba(0,0,0,0.3)" cx="75" cy="75" r="67" fill="none" stroke-width="15" stroke="#fff"/><polygon points="52, 42 52, 107 107, 75" fill="#fff"/></svg>';
        }
        postmarkup += '</div>';  // wallpost-image
    }

    if (comment_title || comment) {
        postmarkup += '<div class="wallpost-text">';


        if (comment_title) {
            postmarkup += '<span class="wallpost-text-title">';
            postmarkup += '<a target="blank" rel="nofollow" href="';
            postmarkup += post_src_href;
            postmarkup += '">';
            var clean_title = sanitizeHtml(comment_title, {
                allowedTags: [ 'a' ],
                allowedAttributes: {
                  'a': [ 'href', 'target', 'rel' ]
                }
              }
            );
            postmarkup += clean_title;
            postmarkup += '</a>';
            postmarkup += '</span>';
            postmarkup += '<br>';
        }

        if (comment_prefix) {
            postmarkup += '<span class="wallpost-text-prefix">';
            if (inreply) {
                postmarkup += '<i class="fa fa-reply"></i>In reply to '
            } else if (isretweet) {
                postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
            }
            postmarkup += comment_prefix;
            postmarkup += '</span>';
            postmarkup += '<br>';
        } else if (isretweet) {
            postmarkup += '<span class="wallpost-text-prefix">';
            postmarkup += '<i class="fa fa-retweet"></i>Retweeted '
            postmarkup += '</span>';
            postmarkup += '<br>';
        }

        comment = linkifyHtml(comment);

        postmarkup += '<span>';
        if (comment) {
            var clean = sanitizeHtml(comment, {
                allowedTags: [],
                allowedAttributes: []
              }
            );

            var posttextsize = highlighted_post ? WallData.getHlPostTextSize() : WallData.getPostTextSize();

            if (posttextsize && posttextsize > 0 && posttextsize < clean.length) {
                clean = clean.substring(0, posttextsize) + '...';
            }
            else {
              clean = sanitizeHtml(comment, {
                    allowedTags: [ 'a' ],
                    allowedAttributes: {
                      'a': [ 'href', 'target', 'rel' ]
                    }
                }
              );
            }

            postmarkup += clean;
        }
        postmarkup += '</span>';

//        if (comment_suffix) {
//            postmarkup += '<br>';
//            postmarkup += '<span class="wallpost-text-suffix">';
//            postmarkup += comment_suffix;
//            postmarkup += '</span>';
//        }

        postmarkup += '</div>';
    }

    postmarkup += '</div>'; // story main content

    if (postHeaderPosition == 'bottom') {
        postmarkup += getPostHeaderMarkup(postobj);
    }

    postmarkup += '<footer>';
    var url = post_src_href;
    var share_url = '';

    if ( postobj.source == "twitter" )
    {
        var sourceid = postobj.sourceid;
        if (sourceid.indexOf('_') > 0) {
            sourceid = sourceid.split('_')[0]
        }

        var reply_url = "https://twitter.com/intent/tweet?in_reply_to=";
        reply_url += sourceid;
        reply_url += '&original_referer=';
        reply_url += encodeURIComponent("http://www.socialmediawall.io");
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += reply_url;
        postmarkup += '"><i class="fa fa-reply"></i></a>';

        var retweet_url = "https://twitter.com/intent/retweet?tweet_id=";
        retweet_url += sourceid;
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += retweet_url;
        postmarkup += '"><i class="fa fa-retweet"></i></a>';


        var favorite_url = "https://twitter.com/intent/favorite?tweet_id=";
        favorite_url += sourceid;
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += favorite_url;
        postmarkup += '"><i class="fa fa-heart"></i></a>';

        share_url = "https://www.facebook.com/sharer.php?";
        share_url += 'u=' + encodeURIComponent(url);
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += share_url;
        postmarkup += '" target="_blank"><i class="fa fa-facebook"></i></a>';
    } else {
        share_url = "https://www.facebook.com/sharer.php?";
        share_url += 'u=' + encodeURIComponent(url);
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += share_url;
        postmarkup += '" target="_blank"><i class="fa fa-facebook"></i></a>';

        share_url = "http://twitter.com/intent/tweet?text=";
        share_url += encodeURIComponent(url);
        postmarkup += '<a class="wallpost-share-button" href="';
        postmarkup += share_url;
        postmarkup += '" target="_blank"><i class="fa fa-twitter"></i></a>';
    }


    share_url = "http://www.linkedin.com/cws/share?lang=en_US&url=";
    share_url += encodeURIComponent(url);
    postmarkup += '<a class="wallpost-share-button" href="';
    postmarkup += share_url;
    postmarkup += '" target="_blank"><i class="fa fa-linkedin"></i></a>';

    share_url = "https://plus.google.com/share?url=";
    share_url += encodeURIComponent(url);
    postmarkup += '<a class="wallpost-share-button" href="';
    postmarkup += share_url;
    postmarkup += '" target="_blank"><i class="fa fa-google-plus"></i></a>';

    postmarkup += '</footer>';

    postmarkup += '</div>';
    postmarkup += '</div>';

    return postmarkup;
}

$(document).delegate("div.wallpost-essence", "click", function(e) {
   e.preventDefault();
   if ($(e.target).is("a")) return;

   var videoUrl = $(this).find("a.wallpost-essence-target").attr("href");
   WallData.playVideo(videoUrl);
});

function embedVideo(video) {
    $('#wallpost-video').removeClass('hide').addClass('show');
    document.getElementById('embed-video-container').innerHTML = unescape(video.html);
}

